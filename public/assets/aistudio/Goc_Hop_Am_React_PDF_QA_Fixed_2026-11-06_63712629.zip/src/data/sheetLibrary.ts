/**
 * Read-only federation. Direct PDF links were checked against Mutopia on 2026-11-06.
 * Third-party sheet pages are indexed as pages, never mislabelled as downloadable PDFs.
 * No third-party files are mirrored or copied into the ZIP.
 */
export type SheetFormat = 'pdf-direct' | 'sheet-page';
export interface SheetSource {
  id: string;
  name: string;
  url: string;
  domain: string;
  pathHint: string;
  kind: string;
}
export interface SheetRecord {
  id: string;
  title: string;
  composer: string;
  genre: string;
  sourceId: string;
  format: SheetFormat;
  url: string;
  instrument?: string;
  license?: string;
}
export const SHEET_SOURCES: ReadonlyArray<SheetSource> = [
  { id: 'hopamnet', name: 'hopam.net', url: 'https://hopam.net/sheet/', domain: 'hopam.net', pathHint: '/sheet', kind: 'Sheet tiếng Việt' },
  { id: 'hav', name: 'Hợp Âm Việt', url: 'https://hopamviet.vn/sheet', domain: 'hopamviet.vn', pathHint: '/sheet', kind: 'Sheet tiếng Việt' },
  { id: 'mutopia', name: 'Mutopia Project', url: 'https://www.mutopiaproject.org/', domain: 'mutopiaproject.org', pathHint: '/ftp', kind: 'PDF bản phổ mở' },
  { id: 'musopen', name: 'Musopen', url: 'https://musopen.org/sheetmusic/', domain: 'musopen.org', pathHint: '/sheetmusic', kind: 'Thư viện cổ điển' },
  { id: 'imslp', name: 'IMSLP', url: 'https://imslp.org/', domain: 'imslp.org', pathHint: '/wiki', kind: 'Thư viện cổ điển' },
  { id: 'openscore', name: 'OpenScore', url: 'https://openscore.cc/', domain: 'openscore.cc', pathHint: '', kind: 'Bản phổ mở' },
  { id: 'musescore', name: 'MuseScore', url: 'https://musescore.com/sheetmusic', domain: 'musescore.com', pathHint: '', kind: 'Bản phổ cộng đồng' },
  { id: 'commons', name: 'Wikimedia Commons', url: 'https://commons.wikimedia.org/wiki/Category:Sheet_music', domain: 'commons.wikimedia.org', pathHint: '/wiki', kind: 'Tư liệu có giấy phép riêng' },
];
export const SHEET_GENRES = [
  'Nhạc Vàng', 'Nhạc Trữ tình', 'Nhạc Trẻ', 'Nhạc Quê hương', 'Nhạc Ngoại lời Việt',
  'Nhạc Đỏ', 'Nhạc Dân ca', 'Nhạc Quốc tế', 'Nhạc Học trò', 'Nhạc Thiếu nhi',
  'Nhạc Thánh ca', 'Nhạc Phật giáo', 'Nhạc Chế - Vui',
];
export const SHEET_RECORDS: ReadonlyArray<SheetRecord> = [
  { id: 'mutopia-vocalise1', title: 'Vocalise № 1', composer: 'Franz Abt', genre: 'Nhạc Quốc tế', sourceId: 'mutopia', format: 'pdf-direct', instrument: 'Giọng hát', license: 'Xem giấy phép tại Mutopia', url: 'https://www.mutopiaproject.org/ftp/AbtF/Vocalise1/Vocalise1-a4.pdf' },
  { id: 'mutopia-swallows', title: 'When the Swallows Homeward Fly', composer: 'Franz Abt', genre: 'Nhạc Quốc tế', sourceId: 'mutopia', format: 'pdf-direct', instrument: 'Giọng hát và piano', license: 'Xem giấy phép tại Mutopia', url: 'https://www.mutopiaproject.org/ftp/AbtF/swallows/swallows-a4.pdf' },
  { id: 'mutopia-giselle', title: 'Giselle – Pas de deux', composer: 'Adolphe Adam', genre: 'Nhạc Quốc tế', sourceId: 'mutopia', format: 'pdf-direct', instrument: 'Piano', license: 'Xem giấy phép tại Mutopia', url: 'https://www.mutopiaproject.org/ftp/AdamA/giselle/giselle-a4.pdf' },
  { id: 'mutopia-minuit', title: 'Minuit Chrétiens', composer: 'Adolphe Adam', genre: 'Nhạc Quốc tế', sourceId: 'mutopia', format: 'pdf-direct', instrument: 'Giọng hát và piano', license: 'Xem giấy phép tại Mutopia', url: 'https://www.mutopiaproject.org/ftp/AdamA/minuit_chretiens/minuit_chretiens-a4.pdf' },
  { id: 'mutopia-alsatian', title: 'The Blue Alsatian Mountains', composer: 'Stephen Adams', genre: 'Nhạc Quốc tế', sourceId: 'mutopia', format: 'pdf-direct', instrument: 'Giọng hát và piano', license: 'Xem giấy phép tại Mutopia', url: 'https://www.mutopiaproject.org/ftp/AdamsS/bluemtns/bluemtns-a4.pdf' },
  { id: 'hopamnet-hoai', title: 'Chiều ngồi bên sông Hoài', composer: 'Phan Bảo Nam', genre: 'Nhạc Trữ tình', sourceId: 'hopamnet', format: 'sheet-page', url: 'https://hopam.net/sheet/chieu-ngoi-ben-song-hoai/' },
  { id: 'hopamnet-xuan', title: 'Mùa xuân về', composer: 'Lê Thúy Hằng', genre: 'Nhạc Quê hương', sourceId: 'hopamnet', format: 'sheet-page', url: 'https://hopam.net/sheet/mua-xuan-ve/' },
  { id: 'hav-me', title: 'Trong vòng tay mẹ', composer: 'Lê Dinh - Dạ Cầm', genre: 'Nhạc Trữ tình', sourceId: 'hav', format: 'sheet-page', url: 'https://hopamviet.vn/sheet/song/trong-vong-tay-me/W8IUDZCO.html' },
  { id: 'hav-nang', title: 'Nắng tôi và em', composer: 'Phạm Chinh Đông', genre: 'Nhạc Trữ tình', sourceId: 'hav', format: 'sheet-page', url: 'https://hopamviet.vn/sheet/song/nang-toi-va-em/W8IUDZ7A.html' },
  { id: 'hav-hoa-than', title: 'Chờ được hóa thân', composer: 'Nguyễn Hoàng Đô', genre: 'Nhạc Trữ tình', sourceId: 'hav', format: 'sheet-page', url: 'https://hopamviet.vn/sheet/song/cho-duoc-hoa-than/W8IUDZ7I.html' },
  { id: 'hav-tho-ngay', title: 'Thơ ngây', composer: 'Nguyễn Ngọc Tú Anh', genre: 'Nhạc Trữ tình', sourceId: 'hav', format: 'sheet-page', url: 'https://hopamviet.vn/sheet/song/tho-ngay/W8IUDZWA.html' },
];
export function normalizeSongText(value: unknown): string {
  return String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[đĐ]/g, 'd').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}
export function safeScoreURL(record: SheetRecord): boolean {
  try {
    const u = new URL(record.url);
    const source = SHEET_SOURCES.find(s => s.id === record.sourceId);
    if (!source || u.protocol !== 'https:' || u.username || u.password || u.hash) return false;
    if (u.hostname !== source.domain && u.hostname !== 'www.' + source.domain) return false;
    return record.format !== 'pdf-direct' || (source.id === 'mutopia' && u.pathname.startsWith('/ftp/') && u.pathname.endsWith('.pdf') && !u.search);
  } catch { return false; }
}
export function searchSheetRecords(query: string, source = 'all', genre = 'all', format = 'all', sort: 'az' | 'za' = 'az'): SheetRecord[] {
  const terms = normalizeSongText(query).split(' ').filter(Boolean);
  return SHEET_RECORDS.filter(r => {
    if (!safeScoreURL(r) || (source !== 'all' && r.sourceId !== source) ||
      (genre !== 'all' && r.genre !== genre) || (format !== 'all' && r.format !== format)) return false;
    const hay = normalizeSongText([r.title, r.composer, r.genre, SHEET_SOURCES.find(s => s.id === r.sourceId)?.name].join(' '));
    return terms.every(term => hay.includes(term));
  }).sort((a, b) => (sort === 'za' ? -1 : 1) * a.title.localeCompare(b.title, 'vi'));
}
export function findMatchingSheet(title: string, composer: string): SheetRecord | undefined {
  const a = normalizeSongText(title), b = normalizeSongText(composer);
  return (!a || !b) ? undefined : SHEET_RECORDS.find(r => safeScoreURL(r) && normalizeSongText(r.title) === a && normalizeSongText(r.composer) === b);
}
export function providerSearchURL(source: SheetSource, query: string): string {
  const q = String(query ?? '').trim().slice(0, 150);
  if (!q) return source.url;
  return 'https://www.google.com/search?' + new URLSearchParams({ q: `site:${source.domain}${source.pathHint} ${q} sheet nhạc` });
}
export interface CatalogHit { id: string; title: string; composer: string; singer: string }
export function parseSitesHits(data: unknown): CatalogHit[] {
  if (!data || typeof data !== 'object' || !('items' in data) || !Array.isArray(data.items)) return [];
  return data.items.filter((x: any) => x && typeof x.title === 'string' && x.title.trim())
    .slice(0, 20).map((x: any) => ({ id: String(x.id ?? ''), title: x.title.trim().slice(0, 200), composer: String(x.author ?? '').trim().slice(0, 160), singer: String(x.singer ?? '').trim().slice(0, 120) }));
}
export const LIVE_CATALOG_API = 'https://goc-hop-am.onwardcrust.chatgpt.site/api/catalog';

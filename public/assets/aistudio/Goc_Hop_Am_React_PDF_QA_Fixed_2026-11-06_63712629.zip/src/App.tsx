import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { SongCatalog } from './components/SongCatalog';
import { SongViewer } from './components/SongViewer';
import { AutoSheetEngine } from './components/AutoSheetEngine';
import { PracticeStudio } from './components/PracticeStudio';
import { ChordDictionary } from './components/ChordDictionary';
import { SecurityAndProvenance } from './components/SecurityAndProvenance';
import { ValidationReport } from './components/ValidationReport';
import { SheetLibrary } from './components/SheetLibrary';
import { INITIAL_SONGS } from './data/mockCatalog';
import { Song, UserRole } from './types';
import { X, Sparkles } from 'lucide-react';

export default function App() {
  const [songs, setSongs] = useState<Song[]>(INITIAL_SONGS);
  const [activeTab, setActiveTab] = useState<string>('catalog');
  const [sheetSearch, setSheetSearch] = useState<string>('');
  const [selectedSong, setSelectedSong] = useState<Song | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [userRole, setUserRole] = useState<UserRole>('member');
  const [isAutoSheetModalOpen, setIsAutoSheetModalOpen] = useState<boolean>(false);

  // When a user selects a song from catalog or studio
  const handleSelectSong = (song: Song) => {
    setSelectedSong(song);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // When a new song is generated via AI Auto Sheet
  const handleSongCreated = (newSong: Song) => {
    setSongs(prev => [newSong, ...prev]);
    setSelectedSong(newSong);
    setIsAutoSheetModalOpen(false);
  };

  // Tab change handler
  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
    setSelectedSong(null); // Return to list view
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800 antialiased selection:bg-orange-500 selection:text-white">
      
      {/* 1. Navigation Bar with Menu Ba Gạch & Smart Search */}
      <Navbar
        activeTab={selectedSong ? '' : activeTab}
        setActiveTab={handleTabChange}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        userRole={userRole}
        setUserRole={setUserRole}
        onOpenAutoSheetModal={() => setIsAutoSheetModalOpen(true)}
      />

      {/* 2. Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {selectedSong ? (
          <SongViewer
            song={selectedSong}
            onBack={() => setSelectedSong(null)}
            onFindSheet={() => {setSheetSearch(selectedSong.title); setActiveTab('sheet-library'); setSelectedSong(null);}}
            onOpenAutoSheet={() => {
              setActiveTab('autosheet');
              setSelectedSong(null);
            }}
          />
        ) : (
          <>
            {activeTab === 'catalog' && (
              <SongCatalog
                songs={songs}
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
                onSelectSong={handleSelectSong}
                onOpenAutoSheet={() => setActiveTab('autosheet')}
              />
            )}

            {activeTab === 'sheet-library' && <SheetLibrary initialQuery={sheetSearch} />}

            {activeTab === 'autosheet' && (
              <AutoSheetEngine
                onSongCreated={handleSongCreated}
                onSelectSong={handleSelectSong}
                onOpenSheet={(q) => { setSheetSearch(q); setActiveTab('sheet-library'); }}
              />
            )}

            {activeTab === 'practice' && (
              <PracticeStudio
                songs={songs}
                onSelectSong={handleSelectSong}
              />
            )}

            {activeTab === 'dictionary' && (
              <ChordDictionary />
            )}

            {activeTab === 'security' && (
              <SecurityAndProvenance
                songs={songs}
                userRole={userRole}
                onRestoreSongs={(restored) => setSongs(restored)}
              />
            )}

            {activeTab === 'report' && (
              <ValidationReport
                songs={songs}
              />
            )}
          </>
        )}
      </main>

      {/* 3. Footer */}
      <Footer onSelectTab={handleTabChange} />

      {/* 4. Quick Auto Sheet Modal Dialog */}
      {isAutoSheetModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 p-6 sm:p-8 relative">
            <button
              onClick={() => setIsAutoSheetModalOpen(false)}
              className="absolute top-6 right-6 p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
              aria-label="Đóng cửa sổ tạo sheet"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="mb-6">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-100 text-orange-700 text-xs font-bold mb-2">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Auto Sheet AI Engine</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900">
                Tạo Bản Ký Âm & Hợp Âm Tự Động
              </h3>
              <p className="text-xs text-slate-500">
                Tự động nhận dạng nốt, nhịp, hợp âm từ liên kết YouTube hoặc âm thanh thực tế.
              </p>
            </div>

            <AutoSheetEngine
              onSongCreated={handleSongCreated}
              onOpenSheet={(q) => { setSheetSearch(q); setActiveTab('sheet-library'); setSelectedSong(null); setIsAutoSheetModalOpen(false); }}
              onSelectSong={(song) => {
                setIsAutoSheetModalOpen(false);
                handleSelectSong(song);
              }}
            />
          </div>
        </div>
      )}

    </div>
  );
}

import React from 'react';
import { FileMusic, Music, ShieldCheck, Heart, Github, ExternalLink, Cpu, CheckCircle2, Sparkles } from 'lucide-react';

interface FooterProps {
  onSelectTab: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectTab }) => {
  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 transition-colors mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          
          {/* Column 1: Brand & Identity */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-600 flex items-center justify-center text-white shadow-md">
                <Music className="w-5 h-5 stroke-[2.5]" />
              </div>
              <span className="font-extrabold text-xl text-white tracking-tight">
                Góc Hợp Âm
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-400 border border-orange-500/30">
                PRO v2.5.0
              </span>
            </div>
            
            <p className="text-sm text-slate-400 leading-relaxed max-w-sm">
              Nền tảng hợp âm, sheet nhạc tự động và phòng luyện tập âm nhạc đa nhạc cụ (Guitar, Piano, Organ) đạt chuẩn quốc tế. Tích hợp AI nhận dạng đa nguồn, bảo mật OWASP ASVS 5.0 và kiểm soát bản quyền minh bạch.
            </p>

            {/* Badges */}
            <div className="flex flex-wrap gap-2 pt-1">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-emerald-950/60 text-emerald-400 border border-emerald-800/60">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Bản React thử nghiệm
              </span>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-blue-950/60 text-blue-400 border border-blue-800/60">
                <Cpu className="w-3.5 h-3.5" />
                Chi phí triển khai chưa xác minh
              </span>
            </div>
          </div>

          {/* Column 2: Tính năng cốt lõi */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Tính Năng Cốt Lõi
            </h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <button onClick={() => onSelectTab('catalog')} className="hover:text-orange-400 transition-colors text-left">
                  Kho Bài Hát Đa Nguồn
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('sheet-library')} className="hover:text-orange-400 transition-colors text-left flex items-center gap-1">
                  <FileMusic className="w-3.5 h-3.5" /> Thư Viện Sheet PDF
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('autosheet')} className="hover:text-orange-400 transition-colors text-left flex items-center gap-1">
                  <span>Auto Sheet AI (P2)</span>
                  <span className="text-[9px] px-1 py-0.2 rounded bg-orange-500/20 text-orange-400 font-bold">Mới</span>
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('practice')} className="hover:text-orange-400 transition-colors text-left">
                  Phòng Luyện Tập Đa Nhạc Cụ
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('dictionary')} className="hover:text-orange-400 transition-colors text-left">
                  Bảng Hợp Âm Guitar & Piano
                </button>
              </li>
              <li>
                <span className="text-slate-500">Đồng Bộ Video & Lời Tự Động</span>
              </li>
            </ul>
          </div>

          {/* Column 3: Nhạc cụ & Luyện tập */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Luyện Tập Chuyên Sâu
            </h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <button onClick={() => onSelectTab('practice')} className="hover:text-orange-400 transition-colors text-left">
                  Phím Đàn Piano & Organ Ảo
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('practice')} className="hover:text-orange-400 transition-colors text-left">
                  Cần Đàn Guitar Fretboard
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('practice')} className="hover:text-orange-400 transition-colors text-left">
                  Máy Đập Nhịp (Metronome)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('practice')} className="hover:text-orange-400 transition-colors text-left">
                  Luyện Tập Theo Đoạn (Loop A-B)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('practice')} className="hover:text-orange-400 transition-colors text-left">
                  Thu Âm & Quay Màn Hình
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Bảo mật & Tuân thủ */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Bảo Mật & Pháp Lý
            </h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <button onClick={() => onSelectTab('security')} className="hover:text-orange-400 transition-colors text-left flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>OWASP ASVS 5.0 Audit</span>
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('security')} className="hover:text-orange-400 transition-colors text-left">
                  Sổ Nguồn Gốc (Provenance)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('report')} className="hover:text-orange-400 transition-colors text-left">
                  Báo Cáo Nghiệm Thu P5
                </button>
              </li>
              <li>
                <a 
                  href="https://github.com/duyuyd/goc-hop-am" 
                  target="_blank" 
                  rel="noreferrer"
                  className="hover:text-orange-400 transition-colors inline-flex items-center gap-1 text-slate-400"
                >
                  <Github className="w-3.5 h-3.5" />
                  <span>GitHub Kho Nguồn</span>
                  <ExternalLink className="w-3 h-3 text-slate-500" />
                </a>
              </li>
              <li>
                <a 
                  href="https://goc-hop-am.onwardcrust.chatgpt.site/" 
                  target="_blank" 
                  rel="noreferrer"
                  className="hover:text-orange-400 transition-colors inline-flex items-center gap-1 text-slate-400"
                >
                  <span>Website Sites Đang Chạy</span>
                  <ExternalLink className="w-3 h-3 text-slate-500" />
                </a>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span>© 2026 Góc Hợp Âm. Phát triển vì tình yêu âm nhạc Việt Nam.</span>
          </div>
          <div className="flex items-center gap-6">
            <span>Project ID: appgprj_6ae93d0e853c8191bc61999c745a657c</span>
            <span className="hidden md:inline">Unicode NFC/NFD Chuẩn</span>
            <span>Chi phí tùy nền tảng</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

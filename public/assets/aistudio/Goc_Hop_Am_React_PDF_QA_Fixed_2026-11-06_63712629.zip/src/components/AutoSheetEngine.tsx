import React, { useMemo, useState } from 'react';
import { AlertCircle, ExternalLink, FileMusic, Search, Sparkles } from 'lucide-react';
import { Song } from '../types';
import { findMatchingSheet, providerSearchURL, safeScoreURL, SHEET_SOURCES } from '../data/sheetLibrary';

interface AutoSheetEngineProps {
  /** Reserved for a future verified transcription pipeline; never called by this lookup-only UI. */
  onSongCreated?: (song: Song) => void;
  onSelectSong?: (song: Song) => void;
  onOpenSheet?: (query: string) => void;
}

/** Safe replacement for the prior timer-based fabricated “AI sheet”.
 * It finds real metadata only; it never fabricates lyrics, MIDI or confidence scores.
 */
export const AutoSheetEngine: React.FC<AutoSheetEngineProps> = ({ onOpenSheet }) => {
  const [songTitle, setSongTitle] = useState('');
  const [composer, setComposer] = useState('');
  const [searched, setSearched] = useState(false);
  const exact = useMemo(() => findMatchingSheet(songTitle, composer), [songTitle, composer]);
  const phrase = `${songTitle.trim()} ${composer.trim()}`.trim();
  const runLookup = () => { if (songTitle.trim()) setSearched(true); };

  return <div className="space-y-6">
    <section className="bg-white p-5 sm:p-8 rounded-3xl border border-slate-200 space-y-3">
      <div className="flex items-center gap-2 text-purple-700 text-sm font-bold"><Sparkles className="w-4 h-4" /> TÌM BẢN PHỔ THẬT</div>
      <h2 className="text-xl sm:text-2xl font-extrabold">Tra sheet và nguồn ký âm</h2>
      <p className="text-sm text-slate-600">Chưa có bộ máy phân tích âm thanh/MIDI đáng tin cậy trên bản React này. Bản tra cứu không tự tạo PDF, không bịa giai điệu, và không báo phần trăm chính xác khi chưa đo.</p>
      <div className="grid sm:grid-cols-2 gap-3">
        <label className="text-sm font-semibold">Tên bài hát
          <input value={songTitle} maxLength={140} onChange={e => { setSongTitle(e.target.value); setSearched(false); }} placeholder="Ví dụ: Hạ Trắng" className="block mt-1 w-full border border-slate-300 rounded-xl p-2.5 text-sm" />
        </label>
        <label className="text-sm font-semibold">Nhạc sĩ (nếu biết)
          <input value={composer} maxLength={140} onChange={e => { setComposer(e.target.value); setSearched(false); }} placeholder="Ví dụ: Trịnh Công Sơn" className="block mt-1 w-full border border-slate-300 rounded-xl p-2.5 text-sm" />
        </label>
      </div>
      <div className="flex flex-wrap gap-3">
        <button disabled={!songTitle.trim()} onClick={runLookup} className="bg-orange-600 text-white font-bold text-sm rounded-xl px-4 py-2.5 disabled:opacity-50 flex items-center gap-2"><Search className="w-4 h-4"/> Tra sheet theo bài</button>
        <button disabled={!songTitle.trim() || !onOpenSheet} onClick={() => onOpenSheet?.(songTitle)} className="border border-orange-500 text-orange-700 font-bold text-sm rounded-xl px-4 py-2.5 disabled:opacity-50 flex items-center gap-2"><FileMusic className="w-4 h-4"/> Mở thư viện Sheet PDF</button>
      </div>
    </section>
    {searched && <section aria-live="polite" className="bg-white p-5 sm:p-8 rounded-3xl border border-slate-200 space-y-4">
      <h3 className="text-lg font-bold">Kết quả kiểm tra nguồn</h3>
      {exact && safeScoreURL(exact)
        ? <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-950">
            <strong>Đã khớp tên bài và nhạc sĩ trong danh mục nguồn</strong>
            <p className="text-sm my-2">{exact.title} — {exact.composer} ({exact.format === 'pdf-direct' ? 'PDF gốc' : 'trang sheet của nguồn'})</p>
            <a href={exact.url} target="_blank" rel="noopener noreferrer" className="font-semibold underline text-sm">Mở bản phổ tại nguồn <ExternalLink className="inline w-4 h-4" /></a>
          </div>
        : <div className="flex items-start gap-2 p-4 rounded-xl border border-amber-200 bg-amber-50 text-amber-950 text-sm"><AlertCircle className="shrink-0 w-5 h-5"/> Chưa đối chiếu được bản sheet đúng tên bài và nhạc sĩ trong danh mục đã kiểm tra. Đây không phải kết luận rằng bài hát không có sheet.</div>
      }
      <p className="text-sm text-slate-600">Tìm tiếp ở các website nguồn (kết quả tìm kiếm chưa phải PDF đã xác minh):</p>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {SHEET_SOURCES.map(source => <a key={source.id} href={providerSearchURL(source, phrase)} target="_blank" rel="noopener noreferrer" className="text-sm text-orange-800 underline p-2 border rounded-lg break-words">{source.name} <ExternalLink className="inline w-3 h-3" /></a>)}
      </div>
    </section>}
    <p className="text-xs text-slate-500">Để tạo bản phổ từ audio thực, cần bộ xử lý âm thanh và bước xác minh nốt/trường độ. Chức năng đó chưa được triển khai trong bản này.</p>
  </div>;
};

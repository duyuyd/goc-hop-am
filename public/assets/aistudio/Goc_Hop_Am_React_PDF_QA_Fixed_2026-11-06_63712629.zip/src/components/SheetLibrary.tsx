import React, { useEffect, useMemo, useState } from 'react';
import { ExternalLink, FileMusic, FileText, Search, Music2, X, Library, AlertCircle } from 'lucide-react';
import { SHEET_SOURCES, SHEET_GENRES, SheetRecord, searchSheetRecords, providerSearchURL,
  parseSitesHits, findMatchingSheet, LIVE_CATALOG_API, safeScoreURL, type CatalogHit } from '../data/sheetLibrary';

interface Props { initialQuery?: string }
export const SheetLibrary: React.FC<Props> = ({ initialQuery = '' }) => {
  const [query, setQuery] = useState(initialQuery);
  const [source, setSource] = useState('all');
  const [genre, setGenre] = useState('all');
  const [format, setFormat] = useState('all');
  const [sort, setSort] = useState<'az' | 'za'>('az');
  const [opened, setOpened] = useState<SheetRecord | null>(null);
  const [catalogHits, setCatalogHits] = useState<CatalogHit[]>([]);
  const [catalogState, setCatalogState] = useState<'idle' | 'loading' | 'ok' | 'unavailable'>('idle');
  useEffect(() => { setQuery(initialQuery); }, [initialQuery]);
  const matched = useMemo(() => searchSheetRecords(query, source, genre, format, sort), [query, source, genre, format, sort]);

  useEffect(() => {
    const q = query.trim().slice(0, 140);
    setCatalogHits([]);
    if (q.length < 3) { setCatalogState('idle'); return; }
    const abort = new AbortController();
    const timer = window.setTimeout(async () => {
      try {
        setCatalogState('loading');
        const url = new URL(LIVE_CATALOG_API);
        url.searchParams.set('mode', 'search');
        url.searchParams.set('q', q);
        const response = await fetch(url.toString(), { signal: abort.signal, headers: { Accept: 'application/json' } });
        if (!response.ok) throw Error('API');
        const data = parseSitesHits(await response.json());
        if (!abort.signal.aborted) { setCatalogHits(data); setCatalogState('ok'); }
      } catch {
        if (!abort.signal.aborted) { setCatalogHits([]); setCatalogState('unavailable'); }
      }
    }, 400);
    return () => { window.clearTimeout(timer); abort.abort(); };
  }, [query]);

  const openPdf = (record: SheetRecord) => {
    if (record.format !== 'pdf-direct' || !safeScoreURL(record)) return;
    setOpened(record);
  };
  const selectedSource = SHEET_SOURCES.filter(s => source === 'all' || source === s.id);
  const googleLinks = (phrase: string, sources = selectedSource) => sources.map(s => (
    <a key={s.id} href={providerSearchURL(s, phrase)} target="_blank" rel="noopener noreferrer"
       className="inline-flex items-center gap-1 text-xs font-semibold text-orange-700 hover:underline underline-offset-2">
      {s.name}<ExternalLink className="w-3 h-3" />
    </a>
  ));
  return <div className="space-y-6">
    <div className="bg-gradient-to-br from-orange-600 via-amber-600 to-rose-600 text-white rounded-3xl p-6 sm:p-8">
      <div className="flex gap-2 items-center text-sm font-semibold"><Library className="w-5 h-5"/> GÓC HỢP ÂM · THƯ VIỆN PDF ĐA NGUỒN</div>
      <h1 className="font-extrabold text-2xl sm:text-3xl my-2">Sheet nhạc theo từng bài hát</h1>
      <p className="text-sm text-white/90 max-w-3xl">Tìm bản phổ tiếng Việt và quốc tế. Chỉ bản ghi có PDF trực tiếp mới mở trong trang; các bản sheet còn lại dẫn về đúng website nguồn.</p>
    </div>
    <div className="bg-white p-4 sm:p-6 rounded-2xl border border-slate-200 space-y-3">
      <label htmlFor="sheet-query" className="text-sm font-semibold block">Tên bài hát hoặc nhạc sĩ</label>
      <div className="relative"><Search className="absolute left-3 top-3.5 w-4 h-4 text-slate-400"/>
        <input id="sheet-query" aria-label="Tìm sheet nhạc" value={query} onChange={e => setQuery(e.target.value)} maxLength={140}
          className="w-full border border-slate-300 rounded-lg py-2.5 pl-10 pr-10 text-sm" placeholder="Nhập tiếng Việt có dấu hoặc không dấu" />
        {!!query && <button className="absolute right-3 top-3 text-slate-500" onClick={() => setQuery('')} aria-label="Xóa tìm kiếm"><X className="w-4 h-4" /></button>}
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <label className="text-xs font-semibold">Website nguồn<select value={source} onChange={e => setSource(e.target.value)} className="block w-full rounded-lg p-2 border border-slate-300 text-sm mt-1"><option value="all">Tất cả</option>{SHEET_SOURCES.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select></label>
        <label className="text-xs font-semibold">Thể loại<select value={genre} onChange={e => setGenre(e.target.value)} className="block w-full rounded-lg p-2 border border-slate-300 text-sm mt-1"><option value="all">Tất cả</option>{SHEET_GENRES.map(g => <option key={g} value={g}>{g}</option>)}</select></label>
        <label className="text-xs font-semibold">Định dạng<select value={format} onChange={e => setFormat(e.target.value)} className="block w-full rounded-lg p-2 border border-slate-300 text-sm mt-1"><option value="all">Tất cả</option><option value="pdf-direct">PDF trực tiếp</option><option value="sheet-page">Trang sheet nguồn</option></select></label>
        <label className="text-xs font-semibold">Sắp xếp<select value={sort} onChange={e => setSort(e.target.value as 'az'|'za')} className="block w-full rounded-lg p-2 border border-slate-300 text-sm mt-1"><option value="az">A–Z</option><option value="za">Z–A</option></select></label>
      </div>
      <p className="text-xs text-slate-500">{matched.length} bản ghi phù hợp · {matched.filter(r => r.format === 'pdf-direct').length} PDF trực tiếp. Đây không phải số lượng sheet đã lưu trên máy chủ.</p>
    </div>

    {opened && <section aria-label="Xem bản nhạc PDF" className="bg-white rounded-2xl p-4 border border-orange-300 space-y-3">
      <div className="flex justify-between gap-3 items-start"><div><h2 className="font-bold text-lg">{opened.title}</h2><p className="text-xs text-slate-500">{opened.composer} · {opened.license || 'Theo nguồn gốc'}</p></div><button onClick={() => setOpened(null)} aria-label="Đóng PDF"><X className="w-5 h-5" /></button></div>
      <div className="flex gap-4 flex-wrap text-sm font-semibold text-orange-700"><a href={opened.url} target="_blank" rel="noopener noreferrer">Mở / tải PDF gốc <ExternalLink className="w-3 h-3 inline" /></a><a href={SHEET_SOURCES.find(x => x.id === opened.sourceId)?.url} target="_blank" rel="noopener noreferrer">Kiểm tra giấy phép nguồn</a></div>
      <iframe src={opened.url} title={`PDF ${opened.title}`} referrerPolicy="no-referrer" className="w-full rounded-lg border border-slate-200 bg-white h-[65vh] sm:h-[78vh]" />
      <p className="text-xs text-slate-500">Nếu trình duyệt chặn khung PDF, hãy mở liên kết PDF gốc bên trên.</p>
    </section>}

    <section className="space-y-3"><h2 className="font-bold text-xl">Bản phổ đã đối chiếu nguồn</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {matched.map(r => <article key={r.id} className="border border-slate-200 bg-white rounded-2xl p-4 flex flex-col gap-2">
          <div className="text-xs font-semibold text-orange-700 flex items-center gap-1">{r.format === 'pdf-direct' ? <FileText className="w-4 h-4"/> : <FileMusic className="w-4 h-4"/>}{r.format === 'pdf-direct' ? 'PDF trực tiếp' : 'Trang sheet gốc'}</div>
          <h3 className="font-bold text-slate-900">{r.title}</h3><p className="text-sm text-slate-600">{r.composer}</p>
          <p className="text-xs text-slate-500">{SHEET_SOURCES.find(s => s.id === r.sourceId)?.name} · {r.genre}</p>
          <div className="mt-auto pt-3">{r.format === 'pdf-direct' ? <button className="font-semibold bg-orange-600 text-white rounded-lg py-2 px-3 text-sm" onClick={() => openPdf(r)}>Xem PDF</button> : <a className="text-sm font-semibold text-orange-700 hover:underline" href={r.url} target="_blank" rel="noopener noreferrer">Xem sheet tại nguồn <ExternalLink className="w-3 h-3 inline"/></a>}</div>
        </article>)}
        {!matched.length && <p className="text-sm border border-dashed border-slate-300 p-4 rounded-xl text-slate-600">Chưa có bản phổ khớp trong danh mục đã kiểm chứng. Dùng phần tìm tại các website bên dưới.</p>}
      </div>
    </section>

    <section className="space-y-3 bg-white p-4 sm:p-6 rounded-2xl border border-slate-200" aria-label="Tra bài trong Sites">
      <h2 className="font-bold text-xl">Tra đúng bài từ kho Góc Hợp Âm</h2>
      <p className="text-xs text-slate-500">Kết nối API đọc công khai của website Sites; kết quả bài hát không đồng nghĩa đã có sheet PDF. Trình duyệt có thể chặn kết nối chéo (CORS).</p>
      {catalogState === 'idle' && <p className="text-sm text-slate-500">Nhập từ 3 ký tự để tra bài.</p>}
      {catalogState === 'loading' && <p className="text-sm text-slate-500" aria-live="polite">Đang tra bài…</p>}
      {catalogState === 'unavailable' && <p className="text-sm text-amber-800 flex gap-2 items-center" aria-live="polite"><AlertCircle className="w-4 h-4" />Không đọc được API Sites từ địa chỉ hiện tại. Vẫn tìm được tại các nguồn bên dưới.</p>}
      {catalogState === 'ok' && <p className="text-sm text-slate-600" aria-live="polite">{catalogHits.length} kết quả trong trang API hiện tại (không phải số PDF).</p>}
      <div className="space-y-3">{catalogHits.map(song => {const exact = findMatchingSheet(song.title, song.composer);
        return <div key={song.id} className="rounded-xl border border-slate-200 p-3 flex flex-wrap items-center justify-between gap-3">
          <div><div className="font-semibold text-sm">{song.title}</div><div className="text-xs text-slate-500">{song.composer || song.singer || 'Chưa rõ nhạc sĩ'}</div><div className="text-xs text-slate-500">{exact ? 'Đã đối chiếu tên bài + nhạc sĩ' : 'Chưa xác nhận có sheet cùng nhạc sĩ'}</div></div>
          <div className="flex gap-3 flex-wrap items-center">{exact && safeScoreURL(exact) && <a href={exact.url} target="_blank" rel="noopener noreferrer" className="text-xs font-semibold text-emerald-700">{exact.format === 'pdf-direct' ? 'PDF khớp bài' : 'Trang sheet khớp bài'}</a>}{googleLinks(`${song.title} ${song.composer}`, SHEET_SOURCES.filter(s => s.id === 'hopamnet' || s.id === 'hav'))}</div>
        </div>})}</div>
    </section>

    <section className="space-y-3"><h2 className="font-bold text-xl">Tìm thêm từ 8 thư viện</h2><p className="text-sm text-slate-600">Tìm trực tiếp tại nguồn theo tên bài đang nhập. Không tự sao chép bản phổ sang Góc Hợp Âm.</p>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">{selectedSource.map(s => <a href={providerSearchURL(s, query)} key={s.id} target="_blank" rel="noopener noreferrer" className="bg-white p-3 border border-slate-200 rounded-xl hover:border-orange-400"><div className="font-semibold text-sm flex gap-1 items-center">{s.name}<ExternalLink className="w-3 h-3" /></div><p className="text-xs text-slate-500 mt-1">{s.kind}</p></a>)}</div>
    </section>
    <p className="text-xs text-slate-500 flex items-start gap-2"><Music2 className="w-4 h-4 shrink-0"/>Chỉ các PDF Mutopia đã được kiểm chứng đường dẫn. Mọi trang sheet khác vẫn ở website gốc; điều kiện tải tùy nguồn.</p>
  </div>;
};

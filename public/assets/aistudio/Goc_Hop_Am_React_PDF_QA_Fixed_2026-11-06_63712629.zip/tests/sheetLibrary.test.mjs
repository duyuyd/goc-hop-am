import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  SHEET_SOURCES, SHEET_RECORDS, SHEET_GENRES, normalizeSongText,
  searchSheetRecords, safeScoreURL, providerSearchURL, findMatchingSheet,
  parseSitesHits, LIVE_CATALOG_API
} from '../src/data/sheetLibrary.ts';

test('8 sources, 13 categories, 5 real PDF links + 6 sheet pages', () => {
  assert.equal(SHEET_SOURCES.length, 8);
  assert.equal(new Set(SHEET_SOURCES.map(x=>x.domain)).size, 8);
  assert.equal(SHEET_GENRES.length, 13);
  assert.equal(SHEET_RECORDS.filter(x=>x.format==='pdf-direct').length, 5);
  assert.equal(SHEET_RECORDS.filter(x=>x.format==='sheet-page').length, 6);
  assert.ok(SHEET_RECORDS.every(safeScoreURL));
});
test('Vietnamese accent-independent search and type filters',()=>{
  assert.equal(normalizeSongText('Đàn Hát'), 'dan hat');
  assert.equal(searchSheetRecords('CHIEU ngoi ben song hoai').length, 1);
  assert.equal(searchSheetRecords('Hoài', 'hopamnet').length, 1);
  assert.equal(searchSheetRecords('hoai', 'all', 'all', 'pdf-direct').length, 0);
  assert.equal(searchSheetRecords('', 'mutopia', 'all','pdf-direct').length, 5);
});
test('never mark a mismatched composer as having the same sheet',()=>{
  assert.equal(findMatchingSheet('Trong vòng tay mẹ','Sai nhạc sĩ'), undefined);
  assert.equal(findMatchingSheet('Trong vòng tay mẹ','Lê Dinh - Dạ Cầm')?.sourceId, 'hav');
  assert.equal(findMatchingSheet('Trong vòng tay mẹ',''), undefined);
});
test('all links reject spoofed domains and unsafe schemes',()=>{
  const r={...SHEET_RECORDS[0]};
  assert.equal(safeScoreURL({...r,url:'https://www.mutopiaproject.org.evil.org/ftp/test.pdf'}),false);
  assert.equal(safeScoreURL({...r,url:'javascript:alert(1)'}),false);
  assert.equal(safeScoreURL({...r,url:'https://www.mutopiaproject.org/ftp/test.pdf?redirect=x'}),false);
  assert.equal(safeScoreURL({...r,url:'http://www.mutopiaproject.org/ftp/test.pdf'}),false);
});
test('search-source URL and API item parsing',()=>{
  assert.equal(new URL(providerSearchURL(SHEET_SOURCES[0],'Đàn hát')).hostname,'www.google.com');
  assert.equal(providerSearchURL(SHEET_SOURCES[0],''), SHEET_SOURCES[0].url);
  assert.equal(LIVE_CATALOG_API,'https://goc-hop-am.onwardcrust.chatgpt.site/api/catalog');
  assert.deepEqual(parseSitesHits(null),[]);
  assert.deepEqual(parseSitesHits({items:[{title:' '},{title:'Hạ Trắng',author:'Trịnh Công Sơn',id:'W1'}]}),[{id:'W1',title:'Hạ Trắng',composer:'Trịnh Công Sơn',singer:''}]);
});

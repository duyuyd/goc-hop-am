import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = p => readFileSync(new URL(p, import.meta.url), 'utf8');
test('tablet navigation stays visible until desktop navbar is active', () => {
  const s = read('../src/components/Navbar.tsx');
  assert.match(s, /className="flex xl:hidden items-center/);
  assert.match(s, /className="xl:hidden border-t/);
  assert.match(s, /className="hidden xl:flex items-center flex-1/);
  assert.match(s, /className="hidden xl:flex items-center space-x-1"/);
});
test('navigating via search always opens the catalog', () => {
  const s = read('../src/components/Navbar.tsx');
  assert.match(s, /if \(activeTab !== 'catalog'\) setActiveTab\('catalog'\)/);
  assert.equal((s.match(/onChange=\{\(e\) => handleSearchChange\(e\.target\.value\)\}/g)||[]).length, 2);
});
test('AutoSheet no longer emits fabricated songs or a fake confidence score', () => {
  const s = read('../src/components/AutoSheetEngine.tsx');
  assert.doesNotMatch(s,/setInterval\s*\(/);
  assert.doesNotMatch(s,/confidenceScore:\s*95/);
  assert.doesNotMatch(s,/lyricsWithChords:\s*`/);
  assert.match(s,/Tra sheet theo bài/);
  assert.match(s,/findMatchingSheet/);
});
test('both AutoSheet placements link to existing PDF library without a new site', () => {
  const s = read('../src/App.tsx');
  assert.equal((s.match(/onOpenSheet=\{/g)||[]).length, 2);
  assert.match(s,/setActiveTab\('sheet-library'\)/);
});

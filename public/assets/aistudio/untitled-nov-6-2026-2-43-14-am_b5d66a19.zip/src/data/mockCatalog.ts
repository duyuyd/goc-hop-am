import { Song } from '../types';

export const INITIAL_SONGS: Song[] = [
  {
    id: 'song-001',
    title: 'Diễm Xưa',
    composer: 'Trịnh Công Sơn',
    artist: 'Khánh Ly',
    originalKey: 'Am',
    tempo: 76,
    timeSignature: '3/4',
    genre: 'Nhạc Trịnh',
    rhythm: 'Slow Rock / Boston',
    youtubeId: '3UfxU3y0s5o',
    sheetStatus: 'verified_sheet',
    confidenceScore: 99,
    provenance: {
      origin: 'Kho Di Sản Góc Hợp Âm - Bản Ký Âm Chuẩn',
      license: 'Bản quyền sử dụng giáo dục phi thương mại (Creative Commons BY-NC)',
      version: 'v2.4-verified',
      verifiedBy: 'Hội đồng Nhạc lý Góc Hợp Âm',
      lastUpdated: '2026-10-15'
    },
    lyricsWithChords: `[Am] Mưa vẫn mưa bay trên tầng tháp [Dm] cổ
Dài tay em [G] mấy thuở mắt xanh [C] xao [E7]
[Am] Nghe lá thu mưa reo mòn gót [Dm] nhỏ
Đường dài hun [E7] hút cho mắt thêm [Am] sâu.

[Am] Mưa vẫn hay mưa trên hàng lá [Dm] nhỏ
Buổi chiều ngồi [G] ngóng những chuyến mưa [C] qua [E7]
[Am] Trên bước chân em âm thầm lá [Dm] đổ
Chợt hồn xanh [E7] buốt cho mình xót [Am] xa.

ĐK:
Chiều nay còn [Dm] mưa sao em không [Am] lại
Nhớ mãi trong [G] cơn đau vùi
Làm sao có [C] nhau hằn lên nỗi [E7] đau
Bước chân em [Dm] xin về mau [Am]
Mưa vẫn [E7] mưa bay trên tầng tháp [Am] cổ.`,
    sheetMeasures: [
      {
        measureNumber: 1,
        timeSignature: '3/4',
        chords: ['Am'],
        notes: [
          { pitch: 'A4', duration: 'quarter', lyric: 'Mưa' },
          { pitch: 'C5', duration: 'quarter', lyric: 'vẫn' },
          { pitch: 'B4', duration: 'quarter', lyric: 'mưa' }
        ]
      },
      {
        measureNumber: 2,
        chords: ['Am'],
        notes: [
          { pitch: 'A4', duration: 'half', lyric: 'bay' },
          { pitch: 'G4', duration: 'quarter', lyric: 'trên' }
        ]
      },
      {
        measureNumber: 3,
        chords: ['Dm'],
        notes: [
          { pitch: 'F4', duration: 'quarter', lyric: 'tầng' },
          { pitch: 'A4', duration: 'quarter', lyric: 'tháp' },
          { pitch: 'D5', duration: 'quarter', lyric: 'cổ' }
        ]
      },
      {
        measureNumber: 4,
        chords: ['G'],
        notes: [
          { pitch: 'G4', duration: 'dotted-half', lyric: '...' }
        ]
      }
    ],
    tags: ['Kinh điển', 'Nhạc Trịnh', 'Guitar Solo', 'Hợp âm chuẩn', 'Boston']
  },
  {
    id: 'song-002',
    title: 'Nàng Thơ',
    composer: 'Hoàng Dũng',
    artist: 'Hoàng Dũng',
    originalKey: 'C',
    tempo: 72,
    timeSignature: '4/4',
    genre: 'Pop Ballad',
    rhythm: 'Ballad',
    youtubeId: 'Zzn9-ATB9aU',
    sheetStatus: 'ai_generated_sheet',
    confidenceScore: 96,
    provenance: {
      origin: 'AI Auto-Sheet Engine (Gemini Spectral Multi-Harmonic)',
      license: 'Phân tích tự động từ bản thu studio chính thống',
      version: 'v1.2-ai-refined',
      verifiedBy: 'AI Engine (Độ tin cậy 96%)',
      lastUpdated: '2026-11-01'
    },
    lyricsWithChords: `[C] Em, ngày em đánh rơi nụ cười vào [G/B] anh
Có xót xa [Am] cũng qua mau người [Em/G] hỡi
Và [F] em, người gom ánh sao trời [C/E] kia
Gói trọn cả tuổi xuân [Dm7] thì để gửi trao cho [G] anh.

[C] Ta, từng đi qua bao mùa gió [G/B] bay
Ngỡ rằng nắm [Am] tay sẽ đi hết đoạn [Em/G] đường
Mà [F] nào hay mai sau chỉ còn nỗi [C/E] nhớ
Thành phố này vẫn [Dm7] thế, cớ sao vắng [G] em?

ĐK:
Em ơi có [F] nghe chăng tiếng gió [G] về
Tựa hồ câu [Em] chuyện ngày mình chung [Am] lối
Người yêu ơi [Dm7] em hãy là [G] nàng thơ trong khúc ca [C] anh [C7]
Dẫu mai này [F] xa cách đôi [G] bờ
Thì tình anh [Em] vẫn mãi vẹn [Am] nguyên
Em có [Dm7] nghe tiếng thu [G] về thì thầm gọi [C] tên?`,
    sheetMeasures: [
      {
        measureNumber: 1,
        timeSignature: '4/4',
        chords: ['C'],
        notes: [
          { pitch: 'E4', duration: 'half', lyric: 'Em' },
          { pitch: 'G4', duration: 'quarter', lyric: 'ngày' },
          { pitch: 'A4', duration: 'quarter', lyric: 'em' }
        ]
      },
      {
        measureNumber: 2,
        chords: ['G/B'],
        notes: [
          { pitch: 'G4', duration: 'quarter', lyric: 'đánh' },
          { pitch: 'E4', duration: 'quarter', lyric: 'rơi' },
          { pitch: 'D4', duration: 'half', lyric: 'nụ cười' }
        ]
      }
    ],
    tags: ['Pop Ballad', 'Xu hướng', 'Dễ chơi', 'Acoustic Guitar']
  },
  {
    id: 'song-003',
    title: 'Riêng Một Góc Trời',
    composer: 'Ngô Thụy Miên',
    artist: 'Tuấn Ngọc',
    originalKey: 'Em',
    tempo: 68,
    timeSignature: '4/4',
    genre: 'Trữ Tình',
    rhythm: 'Slow Rock',
    youtubeId: 'B-rU9k8_G_o',
    sheetStatus: 'verified_sheet',
    confidenceScore: 99,
    provenance: {
      origin: 'Kho Bản Ký Âm Lưu Trữ Góc Hợp Âm',
      license: 'Bản quyền công cộng và di sản âm nhạc Việt Nam',
      version: 'v3.0-final',
      verifiedBy: 'Trưởng ban thẩm âm Góc Hợp Âm',
      lastUpdated: '2026-09-20'
    },
    lyricsWithChords: `[Em] Tình yêu như nắng, nắng đưa em [B7] về
Bên suối mơ [Em] màng
Trầm [Am] ngâm góc phố, lắng nghe tiếng [Em] lòng
Hồn nghe bơ [B7] vơ.

[Em] Nửa đời phiêu bạt, tìm đâu bóng [Am] hình
Người em năm [D] cũ, nụ cười thơ [G] ngây [B7]
[Em] Giờ đây riêng một góc [Am] trời
Ngồi đếm sao [B7] rơi, thương tiếc một [Em] đời.

ĐK:
Đời vội [Am] vã, người đi tìm [Em] nhau
Đắng cay nghẹn [B7] ngào, mắt ướt mi [Em] sầu [E7]
Tìm về chốn [Am] cũ, bóng xưa nhạt [Em] nhòa
Chỉ còn nỗi [B7] nhớ rêu phong ngập [Em] tràn.`,
    sheetMeasures: [
      {
        measureNumber: 1,
        timeSignature: '4/4',
        chords: ['Em'],
        notes: [
          { pitch: 'E4', duration: 'quarter', lyric: 'Tình' },
          { pitch: 'G4', duration: 'quarter', lyric: 'yêu' },
          { pitch: 'B4', duration: 'half', lyric: 'như nắng' }
        ]
      }
    ],
    tags: ['Tình Khúc', 'Slow Rock', 'Guitar Solo', 'Kinh Điển']
  },
  {
    id: 'song-004',
    title: 'Thành Phố Buồn',
    composer: 'Lam Phương',
    artist: 'Chế Linh',
    originalKey: 'Em',
    tempo: 84,
    timeSignature: '4/4',
    genre: 'Bolero',
    rhythm: 'Bolero',
    youtubeId: 'M5p50a_X4Z8',
    sheetStatus: 'verified_sheet',
    confidenceScore: 98,
    provenance: {
      origin: 'Tuyển tập 100 Ca Khúc Vàng Lam Phương',
      license: 'Được bảo hộ theo quy ước quyền tác giả phi thương mại',
      version: 'v2.1',
      verifiedBy: 'Ban Thẩm Định Góc Hợp Âm',
      lastUpdated: '2026-10-02'
    },
    lyricsWithChords: `[Em] Thành phố nào nhớ không [Am] em
Nơi chúng mình tìm phút êm [Em] đềm
Thành phố nào vừa đi đã [B7] mỏi
Đường quanh co quyện gốc thông [Em] già.

[Em] Quỳ bên em trong góc giáo [Am] đường
Tiếng chuông chiều nhẹ rớt mênh [Em] mang
Lời nguyện cầu hòa trong tiếng [B7] gió
Nguyện trọn đời mình mãi yêu [Em] nhau.

ĐK:
Rồi từ [G] đó, vì cách [C] trở
Duyên tình [D] mình đành lỡ làng [G] thôi [B7]
Người ra [Em] đi không một câu từ [Am] giã
Để thành [B7] phố buồn nhớ khôn [Em] nguôi.`,
    tags: ['Bolero', 'Nhạc Vàng', 'Đà Lạt', 'Guitar Bolero']
  },
  {
    id: 'song-005',
    title: 'Cơn Mưa Ngang Qua',
    composer: 'Sơn Tùng M-TP',
    artist: 'Sơn Tùng M-TP',
    originalKey: 'Dm',
    tempo: 120,
    timeSignature: '4/4',
    genre: 'Pop Dance / R&B',
    rhythm: 'Disco / Modern Pop',
    youtubeId: 'W1OUs3HwIuo',
    sheetStatus: 'ai_generated_sheet',
    confidenceScore: 93,
    provenance: {
      origin: 'AI Auto-Sheet Engine (Gemini Neural Beat & Bassline)',
      license: 'Mô phỏng hòa âm tự động đa luồng',
      version: 'v1.0-ai',
      verifiedBy: 'AI Engine (Độ tin cậy 93%)',
      lastUpdated: '2026-11-03'
    },
    lyricsWithChords: `[Dm] Cơn mưa ngang qua, mang em đi [Bb] xa
[C] Cơn mưa ngang qua, khiến nước mắt [Am] nhạt nhòa
[Dm] Nụ cười ngày nào giờ đâu [Bb] thấy
Chỉ còn [C] lại nỗi xót xa từng [Am] ngày.

[Dm] Quay lưng đi mau cơn mưa dần [Bb] phai
[C] Quên đi câu yêu thương xưa người [Am] trao
[Dm] Đừng tìm về bên anh [Bb] nữa
Để cho nỗi [C] nhớ chìm sâu vào giấc [Dm] mơ.`,
    tags: ['Sơn Tùng M-TP', 'Pop Dance', 'R&B', 'Hiện đại']
  },
  {
    id: 'song-006',
    title: 'Đi Về Nhà',
    composer: 'Hứa Kim Tuyền - Xuân Ty',
    artist: 'Đen Vâu x JustaTee',
    originalKey: 'F#m',
    tempo: 90,
    timeSignature: '4/4',
    genre: 'Acoustic Hip-Hop',
    rhythm: 'Ballad Hip-hop',
    youtubeId: 'vHJm_e_j_4U',
    sheetStatus: 'chord_lyrics_only',
    confidenceScore: 90,
    provenance: {
      origin: 'Cộng đồng Góc Hợp Âm đóng góp',
      license: 'Quyền sử dụng tự do cho học tập & biểu diễn',
      version: 'v1.1-chords',
      verifiedBy: 'Cộng đồng biên soạn',
      lastUpdated: '2026-10-28'
    },
    lyricsWithChords: `[F#m] Đường về nhà là vào tim ta [D]
Dẫu nắng mưa chan hòa [A]
Có mẹ chờ và [E] ba ngóng
[F#m] Đi về nhà, đi về [D] nhà
Cơm canh ngọt bùi [A] nơi ấy
Có ấm êm gia [E] đình.

[F#m] Lao ra đời tìm kiếm giấc [D] mơ
Mang theo hoài bão tuổi trẻ dại [A] khờ
Chông chênh bao ngày nơi phố [E] thị
Chỉ mong phút giây được trở về [F#m] nhà.`,
    tags: ['Đen Vâu', 'Gia Đình', 'Tết', 'Acoustic']
  },
  {
    id: 'song-007',
    title: 'Một Bước Yêu Vạn Dặm Đau',
    composer: 'Mr. Siro',
    artist: 'Mr. Siro',
    originalKey: 'Bb',
    tempo: 70,
    timeSignature: '4/4',
    genre: 'Pop Ballad',
    rhythm: 'Slow Ballad',
    youtubeId: 'q5B4v_7tWjU',
    sheetStatus: 'ai_generated_sheet',
    confidenceScore: 95,
    provenance: {
      origin: 'AI Auto-Sheet Engine (Gemini Neural Piano Model)',
      license: 'Bản phân tích hợp âm nâng cao tự động',
      version: 'v1.4-ai',
      verifiedBy: 'AI Engine (Độ tin cậy 95%)',
      lastUpdated: '2026-11-04'
    },
    lyricsWithChords: `[Bb] Một bước yêu vạn dặm [F/A] đau
Người từng thương sao nỡ buông [Gm] tay biệt ly [Dm/F]
[Eb] Từng hẹn ước đi cùng [Bb/D] nhau
Đến hết con đường nay [Cm7] chỉ còn riêng [F] anh.

ĐK:
Dẫu biết yêu [Eb] người là đớn [F] đau
Mà tim [Dm] anh vẫn mãi khắc [Gm] sâu
Nụ cười [Cm7] ấy, ánh mắt thân quen hôm [F] nào
Giờ tan [Bb] biến như giấc chiêm [Bb7] bao.`,
    tags: ['Mr. Siro', 'Piano Solo', 'Ballad Buồn', 'Dễ Đệm']
  },
  {
    id: 'song-008',
    title: 'Em Dạo Này',
    composer: 'Vũ Đinh Trọng Thắng (Ngọt)',
    artist: 'Ngọt',
    originalKey: 'G',
    tempo: 104,
    timeSignature: '4/4',
    genre: 'Indie Pop',
    rhythm: 'Acoustic Strumming',
    youtubeId: '47dM4lOebv0',
    sheetStatus: 'verified_sheet',
    confidenceScore: 98,
    provenance: {
      origin: 'Bản ký âm tiêu chuẩn Indie Việt',
      license: 'Giáo dục âm nhạc cộng đồng',
      version: 'v2.0',
      verifiedBy: 'Nhạc lý Góc Hợp Âm',
      lastUpdated: '2026-10-10'
    },
    lyricsWithChords: `[G] Em dạo này nhiều khi [C] thấy nhớ
[G] Không còn hay thức khuya nghe [C] nhạc
[Am] Chuyện ngày xưa có người gửi [D] trao
[Bm] Một tình yêu chưa từng đổi [Em] thay
Giờ [Am] em dạo này thế [D] nào?

[G] Còn yêu thích những chiều mưa [C] rơi?
[G] Còn ngân nga câu hát năm [C] xưa?
[Am] Anh thì vẫn thế thôi [D] mà
[Bm] Vẫn một mình cùng cây đàn [Em] ca
Và [Am] viết tiếp những khúc tình [D] ca cho [G] người.`,
    tags: ['Ngọt Band', 'Indie', 'Acoustic Guitar', 'Vui Tươi']
  }
];

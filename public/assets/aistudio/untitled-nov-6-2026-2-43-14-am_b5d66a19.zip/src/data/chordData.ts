import { ChordDetail } from '../types';

export const CHORD_DICTIONARY: Record<string, ChordDetail> = {
  'C': {
    name: 'C',
    root: 'C',
    quality: 'Major',
    notes: ['C', 'E', 'G'],
    pianoKeys: [0, 4, 7], // Relative to C
    guitarFingering: {
      frets: [-1, 3, 2, 0, 1, 0], // x 3 2 0 1 0
      fingers: [-1, 3, 2, 0, 1, 0],
    }
  },
  'Cm': {
    name: 'Cm',
    root: 'C',
    quality: 'Minor',
    notes: ['C', 'Eb', 'G'],
    pianoKeys: [0, 3, 7],
    guitarFingering: {
      frets: [-1, 3, 5, 5, 4, 3],
      fingers: [-1, 1, 3, 4, 2, 1],
      barreAt: 3
    }
  },
  'C7': {
    name: 'C7',
    root: 'C',
    quality: 'Dominant 7th',
    notes: ['C', 'E', 'G', 'Bb'],
    pianoKeys: [0, 4, 7, 10],
    guitarFingering: {
      frets: [-1, 3, 2, 3, 1, 0],
      fingers: [-1, 3, 2, 4, 1, 0]
    }
  },
  'D': {
    name: 'D',
    root: 'D',
    quality: 'Major',
    notes: ['D', 'F#', 'A'],
    pianoKeys: [2, 6, 9],
    guitarFingering: {
      frets: [-1, -1, 0, 2, 3, 2],
      fingers: [-1, -1, 0, 1, 3, 2]
    }
  },
  'Dm': {
    name: 'Dm',
    root: 'D',
    quality: 'Minor',
    notes: ['D', 'F', 'A'],
    pianoKeys: [2, 5, 9],
    guitarFingering: {
      frets: [-1, -1, 0, 2, 3, 1],
      fingers: [-1, -1, 0, 2, 3, 1]
    }
  },
  'D7': {
    name: 'D7',
    root: 'D',
    quality: 'Dominant 7th',
    notes: ['D', 'F#', 'A', 'C'],
    pianoKeys: [2, 6, 9, 0],
    guitarFingering: {
      frets: [-1, -1, 0, 2, 1, 2],
      fingers: [-1, -1, 0, 2, 1, 3]
    }
  },
  'E': {
    name: 'E',
    root: 'E',
    quality: 'Major',
    notes: ['E', 'G#', 'B'],
    pianoKeys: [4, 8, 11],
    guitarFingering: {
      frets: [0, 2, 2, 1, 0, 0],
      fingers: [0, 2, 3, 1, 0, 0]
    }
  },
  'Em': {
    name: 'Em',
    root: 'E',
    quality: 'Minor',
    notes: ['E', 'G', 'B'],
    pianoKeys: [4, 7, 11],
    guitarFingering: {
      frets: [0, 2, 2, 0, 0, 0],
      fingers: [0, 2, 3, 0, 0, 0]
    }
  },
  'E7': {
    name: 'E7',
    root: 'E',
    quality: 'Dominant 7th',
    notes: ['E', 'G#', 'B', 'D'],
    pianoKeys: [4, 8, 11, 2],
    guitarFingering: {
      frets: [0, 2, 0, 1, 0, 0],
      fingers: [0, 2, 0, 1, 0, 0]
    }
  },
  'F': {
    name: 'F',
    root: 'F',
    quality: 'Major',
    notes: ['F', 'A', 'C'],
    pianoKeys: [5, 9, 0],
    guitarFingering: {
      frets: [1, 3, 3, 2, 1, 1],
      fingers: [1, 3, 4, 2, 1, 1],
      barreAt: 1
    }
  },
  'Fm': {
    name: 'Fm',
    root: 'F',
    quality: 'Minor',
    notes: ['F', 'Ab', 'C'],
    pianoKeys: [5, 8, 0],
    guitarFingering: {
      frets: [1, 3, 3, 1, 1, 1],
      fingers: [1, 3, 4, 1, 1, 1],
      barreAt: 1
    }
  },
  'G': {
    name: 'G',
    root: 'G',
    quality: 'Major',
    notes: ['G', 'B', 'D'],
    pianoKeys: [7, 11, 2],
    guitarFingering: {
      frets: [3, 2, 0, 0, 0, 3],
      fingers: [2, 1, 0, 0, 0, 3]
    }
  },
  'Gm': {
    name: 'Gm',
    root: 'G',
    quality: 'Minor',
    notes: ['G', 'Bb', 'D'],
    pianoKeys: [7, 10, 2],
    guitarFingering: {
      frets: [3, 5, 5, 3, 3, 3],
      fingers: [1, 3, 4, 1, 1, 1],
      barreAt: 3
    }
  },
  'G7': {
    name: 'G7',
    root: 'G',
    quality: 'Dominant 7th',
    notes: ['G', 'B', 'D', 'F'],
    pianoKeys: [7, 11, 2, 5],
    guitarFingering: {
      frets: [3, 2, 0, 0, 0, 1],
      fingers: [3, 2, 0, 0, 0, 1]
    }
  },
  'A': {
    name: 'A',
    root: 'A',
    quality: 'Major',
    notes: ['A', 'C#', 'E'],
    pianoKeys: [9, 1, 4],
    guitarFingering: {
      frets: [-1, 0, 2, 2, 2, 0],
      fingers: [-1, 0, 1, 2, 3, 0]
    }
  },
  'Am': {
    name: 'Am',
    root: 'A',
    quality: 'Minor',
    notes: ['A', 'C', 'E'],
    pianoKeys: [9, 0, 4],
    guitarFingering: {
      frets: [-1, 0, 2, 2, 1, 0],
      fingers: [-1, 0, 2, 3, 1, 0]
    }
  },
  'Am7': {
    name: 'Am7',
    root: 'A',
    quality: 'Minor 7th',
    notes: ['A', 'C', 'E', 'G'],
    pianoKeys: [9, 0, 4, 7],
    guitarFingering: {
      frets: [-1, 0, 2, 0, 1, 0],
      fingers: [-1, 0, 2, 0, 1, 0]
    }
  },
  'A7': {
    name: 'A7',
    root: 'A',
    quality: 'Dominant 7th',
    notes: ['A', 'C#', 'E', 'G'],
    pianoKeys: [9, 1, 4, 7],
    guitarFingering: {
      frets: [-1, 0, 2, 0, 2, 0],
      fingers: [-1, 0, 2, 0, 3, 0]
    }
  },
  'B': {
    name: 'B',
    root: 'B',
    quality: 'Major',
    notes: ['B', 'D#', 'F#'],
    pianoKeys: [11, 3, 6],
    guitarFingering: {
      frets: [-1, 2, 4, 4, 4, 2],
      fingers: [-1, 1, 2, 3, 4, 1],
      barreAt: 2
    }
  },
  'Bm': {
    name: 'Bm',
    root: 'B',
    quality: 'Minor',
    notes: ['B', 'D', 'F#'],
    pianoKeys: [11, 2, 6],
    guitarFingering: {
      frets: [-1, 2, 4, 4, 3, 2],
      fingers: [-1, 1, 3, 4, 2, 1],
      barreAt: 2
    }
  },
  'B7': {
    name: 'B7',
    root: 'B',
    quality: 'Dominant 7th',
    notes: ['B', 'D#', 'F#', 'A'],
    pianoKeys: [11, 3, 6, 9],
    guitarFingering: {
      frets: [-1, 2, 1, 2, 0, 2],
      fingers: [-1, 2, 1, 3, 0, 4]
    }
  },
  'Bb': {
    name: 'Bb',
    root: 'Bb',
    quality: 'Major',
    notes: ['Bb', 'D', 'F'],
    pianoKeys: [10, 2, 5],
    guitarFingering: {
      frets: [-1, 1, 3, 3, 3, 1],
      fingers: [-1, 1, 2, 3, 4, 1],
      barreAt: 1
    }
  },
  'F#m': {
    name: 'F#m',
    root: 'F#',
    quality: 'Minor',
    notes: ['F#', 'A', 'C#'],
    pianoKeys: [6, 9, 1],
    guitarFingering: {
      frets: [2, 4, 4, 2, 2, 2],
      fingers: [1, 3, 4, 1, 1, 1],
      barreAt: 2
    }
  }
};

import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  Clock, 
  Repeat, 
  Mic, 
  Square, 
  Sliders, 
  Volume2, 
  KeyRound, 
  Music, 
  ShieldCheck,
  Video,
  Layers,
  Sparkles
} from 'lucide-react';
import { soundEngine, getChordNotes } from '../utils/musicLogic';
import { Song } from '../types';

interface PracticeStudioProps {
  songs: Song[];
  onSelectSong: (song: Song) => void;
}

export const PracticeStudio: React.FC<PracticeStudioProps> = ({ songs, onSelectSong }) => {
  const [selectedSong, setSelectedSong] = useState<Song>(songs[0]);
  const [instrument, setInstrument] = useState<'guitar' | 'piano' | 'organ'>('guitar');
  const [bpm, setBpm] = useState(76);
  const [metronomeOn, setMetronomeOn] = useState(false);
  const [activeBeat, setActiveBeat] = useState(1);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  const [loopActive, setLoopActive] = useState(false);
  const [loopA, setLoopA] = useState(0); // seconds
  const [loopB, setLoopB] = useState(16); // seconds
  const [isScreenRecording, setIsScreenRecording] = useState(false);
  
  const timerRef = useRef<number | null>(null);

  // Metronome sound loop
  useEffect(() => {
    if (metronomeOn) {
      const ms = (60 / bpm) * 1000;
      let beat = 1;
      timerRef.current = window.setInterval(() => {
        soundEngine.playMetronomeTick(beat === 1);
        setActiveBeat(beat);
        beat = beat >= 4 ? 1 : beat + 1;
      }, ms);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      setActiveBeat(1);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [metronomeOn, bpm]);

  // Screen recording helper using getDisplayMedia
  const toggleScreenRecording = async () => {
    if (isScreenRecording) {
      setIsScreenRecording(false);
    } else {
      try {
        if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) {
          const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
          setIsScreenRecording(true);
          stream.getVideoTracks()[0].onended = () => setIsScreenRecording(false);
        } else {
          alert('Trình duyệt chưa hỗ trợ quay màn hình trực tiếp.');
        }
      } catch (err) {
        console.warn('Screen recording rejected:', err);
      }
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Studio Header */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-100 text-orange-700 text-xs font-bold mb-2">
            <Music className="w-3.5 h-3.5" />
            <span>Phòng Luyện Tập Đa Nhạc Cụ (P3 Advanced Practice)</span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900">
            Studio Luyện Tập Âm Nhạc Chuyên Nghiệp
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 max-w-xl">
            Tích hợp đầy đủ máy đập nhịp trực quan, đổi tốc độ phát không đổi cao độ, luyện tập lặp đoạn (Loop A-B), và thu âm / quay video đối chiếu.
          </p>
        </div>

        {/* Selected Song Selector */}
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold text-slate-500">Bài đang luyện:</span>
          <select
            value={selectedSong.id}
            onChange={(e) => {
              const found = songs.find(s => s.id === e.target.value);
              if (found) {
                setSelectedSong(found);
                setBpm(found.tempo);
              }
            }}
            className="bg-slate-100 border border-slate-200 font-bold text-xs rounded-xl px-3 py-2 text-slate-800 outline-none"
          >
            {songs.map(s => (
              <option key={s.id} value={s.id}>
                {s.title} ({s.originalKey} - {s.rhythm})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Control Station Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Module 1: Metronome Station */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-600" />
              <span>Máy Đập Nhịp (Metronome)</span>
            </h3>
            <span className="text-xs font-mono font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
              {bpm} BPM
            </span>
          </div>

          {/* Visual 4-beat indicators */}
          <div className="grid grid-cols-4 gap-2 py-2">
            {[1, 2, 3, 4].map(b => (
              <div
                key={b}
                className={`h-10 rounded-xl flex items-center justify-center font-black text-sm transition-all ${
                  activeBeat === b && metronomeOn
                    ? b === 1
                      ? 'bg-rose-500 text-white scale-105 shadow-md shadow-rose-500/30'
                      : 'bg-emerald-500 text-white scale-105 shadow-md shadow-emerald-500/30'
                    : 'bg-slate-100 text-slate-400'
                }`}
              >
                {b}
              </div>
            ))}
          </div>

          {/* BPM Slider & Tap */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs text-slate-500 font-medium">
              <span>Chậm (40)</span>
              <span>Nhanh (220)</span>
            </div>
            <input
              type="range"
              min="40"
              max="220"
              value={bpm}
              onChange={(e) => setBpm(Number(e.target.value))}
              className="w-full accent-emerald-600 cursor-pointer"
            />
          </div>

          <button
            onClick={() => setMetronomeOn(!metronomeOn)}
            className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors ${
              metronomeOn
                ? 'bg-rose-600 text-white hover:bg-rose-700'
                : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm'
            }`}
          >
            {metronomeOn ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{metronomeOn ? 'Tắt Máy Đập Nhịp' : 'Bật Máy Đập Nhịp'}</span>
          </button>
        </div>

        {/* Module 2: Loop A-B & Speed Trainer */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Repeat className="w-4 h-4 text-blue-600" />
              <span>Luyện Đoạn Khó (Loop A-B)</span>
            </h3>
            <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${
              loopActive ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-500'
            }`}>
              {loopActive ? 'Đang Lặp' : 'Tắt'}
            </span>
          </div>

          <p className="text-xs text-slate-500">
            Đặt điểm A và điểm B để lặp lại một câu hát hoặc đoạn solo khó cho đến khi thuần thục.
          </p>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
              <span className="block text-[10px] font-bold text-slate-400">Điểm A (Bắt đầu):</span>
              <span className="text-sm font-mono font-bold text-slate-800">{loopA}s</span>
            </div>
            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
              <span className="block text-[10px] font-bold text-slate-400">Điểm B (Kết thúc):</span>
              <span className="text-sm font-mono font-bold text-slate-800">{loopB}s</span>
            </div>
          </div>

          {/* Speed Presets */}
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-slate-500">Tốc độ phát:</span>
            <div className="flex gap-1">
              {[0.5, 0.75, 1.0, 1.25, 1.5].map((spd) => (
                <button
                  key={spd}
                  onClick={() => setPlaybackSpeed(spd)}
                  className={`flex-1 py-1 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    playbackSpeed === spd
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {spd}x
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => setLoopActive(!loopActive)}
            className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer ${
              loopActive
                ? 'bg-blue-600 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Repeat className="w-4 h-4" />
            <span>{loopActive ? 'Hủy Chế Độ Lặp' : 'Kích Hoạt Lặp Đoạn A-B'}</span>
          </button>
        </div>

        {/* Module 3: Screen & Multi-Instrument Capture */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Video className="w-4 h-4 text-purple-600" />
              <span>Ghi Lại Bài Tập & Video</span>
            </h3>
            <span className="text-[11px] font-bold text-purple-600 bg-purple-50 px-2 py-0.5 rounded">
              P3 Tool
            </span>
          </div>

          <p className="text-xs text-slate-500">
            Quay màn hình có kèm âm thanh đàn và giọng hát để lưu lại quá trình tiến bộ của bản thân hoặc chia sẻ với thầy cô.
          </p>

          {/* Instrument switcher */}
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-slate-500">Nhạc cụ đồng hành:</span>
            <div className="grid grid-cols-3 gap-1">
              {(['guitar', 'piano', 'organ'] as const).map(inst => (
                <button
                  key={inst}
                  onClick={() => setInstrument(inst)}
                  className={`py-1.5 rounded-lg text-xs font-bold capitalize transition-colors cursor-pointer ${
                    instrument === inst
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {inst}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={toggleScreenRecording}
            className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors ${
              isScreenRecording
                ? 'bg-red-600 text-white animate-pulse'
                : 'bg-purple-600 text-white hover:bg-purple-700 shadow-sm'
            }`}
          >
            <Video className="w-4 h-4" />
            <span>{isScreenRecording ? 'Dừng Quay Màn Hình' : 'Quay Màn Hình Luyện Tập'}</span>
          </button>
        </div>

      </div>

      {/* Selected Song Quick Access Bar */}
      <div className="bg-orange-50 p-6 rounded-3xl border border-orange-200 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h4 className="font-extrabold text-orange-950 text-base">
            Mở chế độ luyện tập toàn diện cho: {selectedSong.title}
          </h4>
          <p className="text-xs text-orange-800">
            Bao gồm hợp âm căn lời, sheet ký âm MusicXML, phím đàn ảo và video YouTube đồng bộ.
          </p>
        </div>
        <button
          onClick={() => onSelectSong(selectedSong)}
          className="px-5 py-2.5 bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
        >
          Vào Trình Xem Chi Tiết & Luyện Ngay →
        </button>
      </div>

    </div>
  );
};

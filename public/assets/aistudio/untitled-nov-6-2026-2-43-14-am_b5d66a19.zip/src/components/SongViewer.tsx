import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Type, 
  ArrowUp, 
  ArrowDown, 
  Volume2, 
  Sliders, 
  Maximize2, 
  Printer, 
  Share2, 
  ShieldCheck, 
  Sparkles, 
  Youtube, 
  Eye, 
  EyeOff, 
  Mic, 
  Square, 
  Video, 
  Music2, 
  HelpCircle,
  Clock,
  KeyRound,
  Layers,
  ChevronRight
} from 'lucide-react';
import { Song, SheetStatus } from '../types';
import { 
  transposeChord, 
  transposeLyricsText, 
  calculateCapo, 
  soundEngine, 
  parseLyricsLine,
  getChordNotes
} from '../utils/musicLogic';
import { CHORD_DICTIONARY } from '../data/chordData';

interface SongViewerProps {
  song: Song;
  onBack: () => void;
  onOpenAutoSheet: () => void;
}

export const SongViewer: React.FC<SongViewerProps> = ({ song, onBack, onOpenAutoSheet }) => {
  // Practice & Viewer States
  const [transpose, setTranspose] = useState(0);
  const [fontSize, setFontSize] = useState(16); // pt / px
  const [isAutoScrolling, setIsAutoScrolling] = useState(false);
  const [scrollSpeed, setScrollSpeed] = useState(2); // 1 to 5
  const [showVideo, setShowVideo] = useState(true);
  const [selectedChord, setSelectedChord] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'chords' | 'sheet' | 'instruments'>('chords');
  const [selectedInstrument, setSelectedInstrument] = useState<'guitar' | 'piano' | 'organ'>('guitar');
  
  // Metronome State
  const [metronomeRunning, setMetronomeRunning] = useState(false);
  const [bpm, setBpm] = useState(song.tempo || 80);
  const [currentBeat, setCurrentBeat] = useState(1);
  const metronomeTimerRef = useRef<number | null>(null);

  // Audio Recording State
  const [isRecording, setIsRecording] = useState(false);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Auto-scroll loop
  useEffect(() => {
    let animationFrameId: number;
    let lastTime = performance.now();

    const scrollStep = (currentTime: number) => {
      if (isAutoScrolling) {
        const delta = currentTime - lastTime;
        if (delta > 30) {
          window.scrollBy({ top: scrollSpeed * 0.7, behavior: 'instant' });
          lastTime = currentTime;
        }
        animationFrameId = requestAnimationFrame(scrollStep);
      }
    };

    if (isAutoScrolling) {
      animationFrameId = requestAnimationFrame(scrollStep);
    }

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isAutoScrolling, scrollSpeed]);

  // Metronome interval
  useEffect(() => {
    if (metronomeRunning) {
      const intervalMs = (60 / bpm) * 1000;
      let beat = 1;
      const beatsPerMeasure = song.timeSignature.startsWith('3') ? 3 : 4;

      metronomeTimerRef.current = window.setInterval(() => {
        soundEngine.playMetronomeTick(beat === 1);
        setCurrentBeat(beat);
        beat = beat >= beatsPerMeasure ? 1 : beat + 1;
      }, intervalMs);
    } else {
      if (metronomeTimerRef.current) {
        clearInterval(metronomeTimerRef.current);
      }
      setCurrentBeat(1);
    }

    return () => {
      if (metronomeTimerRef.current) {
        clearInterval(metronomeTimerRef.current);
      }
    };
  }, [metronomeRunning, bpm, song.timeSignature]);

  // Handle Transpose
  const currentKey = transposeChord(song.originalKey, transpose);
  const recommendedCapo = calculateCapo(song.originalKey, 'C');

  // Handle Recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const audioUrl = URL.createObjectURL(audioBlob);
        setRecordedAudioUrl(audioUrl);
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.warn('Microphone access denied or not supported:', err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      // Stop all tracks
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  // Play chord sound and set as selected
  const handleChordClick = (chordName: string) => {
    setSelectedChord(chordName);
    soundEngine.playChord(chordName, selectedInstrument);
  };

  // Parse lines for accurate chord-over-lyric alignment
  const lyricsLines = song.lyricsWithChords.split('\n');

  // Status Badge Helper
  const renderStatusBadge = (status: SheetStatus) => {
    switch (status) {
      case 'verified_sheet':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            Bản Ký Âm Xác Minh
          </span>
        );
      case 'ai_generated_sheet':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-purple-100 text-purple-800 border border-purple-200">
            <Sparkles className="w-3.5 h-3.5 text-purple-600" />
            Sheet AI Tự Động ({song.confidenceScore}%)
          </span>
        );
      case 'chord_lyrics_only':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-200">
            <Music2 className="w-3.5 h-3.5 text-amber-600" />
            Hợp Âm & Lời Chuẩn
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Breadcrumb & Actions Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="text-xs font-semibold text-slate-500 hover:text-orange-600 flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-slate-100 transition-colors"
          >
            ← Quay lại danh sách
          </button>
          <span className="text-slate-300">/</span>
          <span className="text-xs font-bold text-slate-700 truncate max-w-xs sm:max-w-md">
            {song.title}
          </span>
        </div>

        {/* Print & Share */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            aria-label="In bản nhạc"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">In Sheet A4</span>
          </button>
          
          {song.sheetStatus !== 'verified_sheet' && (
            <button
              onClick={onOpenAutoSheet}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-gradient-to-r from-orange-500 to-amber-500 rounded-lg hover:from-orange-600 hover:to-amber-600 shadow-xs"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Phân Tích AI Lại</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Song Header Card */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2.5">
              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                {song.title}
              </h1>
              {renderStatusBadge(song.sheetStatus)}
            </div>

            <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-slate-600">
              <div>
                <span className="text-slate-400">Sáng tác:</span>{' '}
                <strong className="text-slate-800">{song.composer}</strong>
              </div>
              <div>
                <span className="text-slate-400">Ca sĩ thể hiện:</span>{' '}
                <strong className="text-slate-800">{song.artist}</strong>
              </div>
              <div>
                <span className="text-slate-400">Điệu:</span>{' '}
                <span className="px-2 py-0.5 rounded bg-orange-50 text-orange-700 font-semibold text-xs">
                  {song.rhythm}
                </span>
              </div>
              <div>
                <span className="text-slate-400">Nhịp:</span>{' '}
                <span className="font-semibold text-slate-800">{song.timeSignature}</span>
              </div>
            </div>

            {/* Provenance and Rights Note */}
            <div className="text-xs text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-100 flex items-start gap-2 max-w-2xl">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-slate-700">Nguồn gốc & Bản quyền:</span>{' '}
                {song.provenance.origin} • {song.provenance.license} (Phiên bản: {song.provenance.version})
              </div>
            </div>
          </div>

          {/* Quick Key & Tempo Stats */}
          <div className="flex items-center gap-3 self-start bg-slate-50 p-3 rounded-2xl border border-slate-200 text-center">
            <div className="px-3 border-r border-slate-200">
              <span className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Tone gốc
              </span>
              <span className="text-lg font-black text-slate-800">
                {song.originalKey}
              </span>
            </div>
            <div className="px-3 border-r border-slate-200">
              <span className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Tone đang chơi
              </span>
              <span className="text-lg font-black text-orange-600">
                {currentKey}
              </span>
            </div>
            <div className="px-3">
              <span className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Tempo
              </span>
              <span className="text-lg font-black text-slate-800">
                {bpm} BPM
              </span>
            </div>
          </div>
        </div>

        {/* Interactive Floating Tool Bar: A+/A-, Transpose, Auto-scroll, Metronome */}
        <div className="mt-8 pt-6 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4">
          
          {/* Controls: A+ / A- Font Size */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
            <span className="text-xs font-bold text-slate-500 px-2 flex items-center gap-1">
              <Type className="w-3.5 h-3.5" />
              Cỡ chữ
            </span>
            <button
              onClick={() => setFontSize(Math.max(12, fontSize - 2))}
              aria-label="Giảm cỡ chữ"
              className="w-7 h-7 bg-white rounded-lg text-xs font-bold text-slate-700 hover:bg-slate-200 shadow-xs flex items-center justify-center cursor-pointer"
            >
              A-
            </button>
            <span className="text-xs font-mono font-bold text-slate-600 px-1">
              {fontSize}px
            </span>
            <button
              onClick={() => setFontSize(Math.min(28, fontSize + 2))}
              aria-label="Tăng cỡ chữ"
              className="w-7 h-7 bg-white rounded-lg text-xs font-bold text-slate-700 hover:bg-slate-200 shadow-xs flex items-center justify-center cursor-pointer"
            >
              A+
            </button>
          </div>

          {/* Controls: Transpose Key +/- */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
            <span className="text-xs font-bold text-slate-500 px-2 flex items-center gap-1">
              <KeyRound className="w-3.5 h-3.5" />
              Đổi Tone
            </span>
            <button
              onClick={() => setTranspose(transpose - 1)}
              aria-label="Giảm nửa cung"
              className="w-7 h-7 bg-white rounded-lg text-xs font-bold text-slate-700 hover:bg-slate-200 shadow-xs flex items-center justify-center cursor-pointer"
            >
              -1
            </button>
            <button
              onClick={() => setTranspose(0)}
              title="Khôi phục tone gốc"
              className="px-2 h-7 bg-white rounded-lg text-xs font-mono font-bold text-orange-600 hover:bg-slate-200 shadow-xs flex items-center justify-center"
            >
              {transpose > 0 ? `+${transpose}` : transpose}
            </button>
            <button
              onClick={() => setTranspose(transpose + 1)}
              aria-label="Tăng nửa cung"
              className="w-7 h-7 bg-white rounded-lg text-xs font-bold text-slate-700 hover:bg-slate-200 shadow-xs flex items-center justify-center cursor-pointer"
            >
              +1
            </button>
          </div>

          {/* Controls: Auto-scroll */}
          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setIsAutoScrolling(!isAutoScrolling)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                isAutoScrolling 
                  ? 'bg-rose-500 text-white shadow-xs' 
                  : 'bg-white text-slate-700 hover:bg-slate-200'
              }`}
            >
              {isAutoScrolling ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isAutoScrolling ? 'Dừng cuộn' : 'Tự cuộn'}</span>
            </button>
            {isAutoScrolling && (
              <div className="flex items-center gap-1 pr-2">
                <span className="text-[10px] text-slate-500">Tốc độ:</span>
                <input
                  type="range"
                  min="1"
                  max="5"
                  value={scrollSpeed}
                  onChange={(e) => setScrollSpeed(Number(e.target.value))}
                  className="w-16 accent-orange-500 cursor-pointer"
                  aria-label="Tốc độ cuộn"
                />
              </div>
            )}
          </div>

          {/* Controls: Metronome (Máy đập nhịp) */}
          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setMetronomeRunning(!metronomeRunning)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                metronomeRunning 
                  ? 'bg-emerald-600 text-white shadow-xs' 
                  : 'bg-white text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>{metronomeRunning ? `Nhịp ${currentBeat}` : 'Máy đập nhịp'}</span>
            </button>
            <div className="flex items-center gap-1 px-1">
              <input
                type="number"
                min="40"
                max="240"
                value={bpm}
                onChange={(e) => setBpm(Number(e.target.value))}
                className="w-12 text-center text-xs font-bold bg-white rounded border border-slate-200 py-0.5 outline-none"
                aria-label="BPM nhịp"
              />
              <span className="text-[10px] font-semibold text-slate-500">BPM</span>
            </div>
          </div>

          {/* YouTube Video Toggle */}
          {song.youtubeId && (
            <button
              onClick={() => setShowVideo(!showVideo)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-colors cursor-pointer ${
                showVideo 
                  ? 'bg-rose-50 text-rose-700 border-rose-200' 
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Youtube className="w-4 h-4 text-rose-600" />
              <span>{showVideo ? 'Ẩn Video' : 'Hiện Video'}</span>
            </button>
          )}

        </div>
      </div>

      {/* Responsive YouTube Player Area (Fix for mobile overflow) */}
      {showVideo && song.youtubeId && (
        <div className="bg-slate-900 rounded-2xl overflow-hidden shadow-md border border-slate-800">
          <div className="p-3 bg-slate-950 flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <Youtube className="w-4 h-4 text-rose-500" />
              <span className="font-semibold text-slate-200">Bản thu tham chiếu YouTube</span>
            </div>
            <span className="text-[11px] text-slate-500">Tối ưu cho cả máy tính & điện thoại</span>
          </div>
          <div className="relative w-full aspect-video">
            <iframe
              src={`https://www.youtube.com/embed/${song.youtubeId}?rel=0`}
              title={`${song.title} - ${song.artist}`}
              className="absolute inset-0 w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        </div>
      )}

      {/* Practice View Switcher: Hợp âm & Lời | Sheet Notation | Nhạc Cụ Ảo (Piano/Guitar) */}
      <div className="flex border-b border-slate-200 gap-2">
        <button
          onClick={() => setActiveTab('chords')}
          className={`pb-3 px-4 text-sm font-bold border-b-2 flex items-center gap-2 transition-colors cursor-pointer ${
            activeTab === 'chords'
              ? 'border-orange-500 text-orange-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Music2 className="w-4 h-4" />
          <span>Hợp Âm & Lời Bài Hát</span>
        </button>

        {song.sheetMeasures && (
          <button
            onClick={() => setActiveTab('sheet')}
            className={`pb-3 px-4 text-sm font-bold border-b-2 flex items-center gap-2 transition-colors cursor-pointer ${
              activeTab === 'sheet'
                ? 'border-orange-500 text-orange-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Ký Âm Sheet Nhạc (MusicXML)</span>
          </button>
        )}

        <button
          onClick={() => setActiveTab('instruments')}
          className={`pb-3 px-4 text-sm font-bold border-b-2 flex items-center gap-2 transition-colors cursor-pointer ${
            activeTab === 'instruments'
              ? 'border-orange-500 text-orange-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Nhạc Cụ Ảo (Guitar / Piano / Organ)</span>
        </button>
      </div>

      {/* TAB CONTENT 1: CHORDS & LYRICS */}
      {activeTab === 'chords' && (
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between text-xs text-slate-500 border-b border-slate-100 pb-3">
            <span>💡 <strong>Mẹo:</strong> Nhấn vào từng hợp âm màu cam để nghe âm thanh mẫu và xem thế bấm.</span>
            {recommendedCapo > 0 && (
              <span className="font-semibold text-orange-700 bg-orange-50 px-2 py-0.5 rounded">
                Gợi ý kẹp Capo ngăn {recommendedCapo} để bấm thế dễ
              </span>
            )}
          </div>

          {/* Render Aligned Lines */}
          <div 
            className="font-mono leading-loose space-y-4 select-text"
            style={{ fontSize: `${fontSize}px` }}
          >
            {lyricsLines.map((line, lineIdx) => {
              if (!line.trim()) {
                return <div key={lineIdx} className="h-4" />;
              }

              // Check if it's a section header like ĐK: or Verse:
              if (line.trim().startsWith('ĐK:') || line.trim().startsWith('Verse:')) {
                return (
                  <div key={lineIdx} className="text-orange-600 font-extrabold text-sm font-sans pt-2">
                    {line}
                  </div>
                );
              }

              // Parse segments
              const parsed = parseLyricsLine(transposeLyricsText(line, transpose));

              return (
                <div key={lineIdx} className="flex flex-wrap items-baseline gap-x-2">
                  {parsed.segments.map((seg, segIdx) => (
                    <div key={segIdx} className="inline-flex flex-col items-start min-w-[1.2rem]">
                      {seg.chord ? (
                        <button
                          onClick={() => handleChordClick(seg.chord!)}
                          title={`Nghe hợp âm ${seg.chord}`}
                          className="text-orange-600 font-extrabold hover:text-orange-700 hover:bg-orange-100 px-1 rounded transition-colors text-xs sm:text-sm font-sans cursor-pointer"
                        >
                          {seg.chord}
                        </button>
                      ) : (
                        <span className="h-4 sm:h-5" />
                      )}
                      <span className="text-slate-800 whitespace-pre">
                        {seg.text || ' '}
                      </span>
                    </div>
                  ))}
                </div>
              );
            })}
          </div>

          {/* Selected Chord Quick Modal / Banner */}
          {selectedChord && (
            <div className="mt-8 p-4 rounded-xl bg-orange-50 border border-orange-200 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-orange-600 text-white font-extrabold flex items-center justify-center text-lg">
                  {selectedChord}
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">
                    Hợp âm {selectedChord}
                  </h4>
                  <p className="text-xs text-slate-600">
                    Gồm các nốt: <strong>{getChordNotes(selectedChord).join(' - ')}</strong>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => soundEngine.playChord(selectedChord, 'guitar')}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-white text-slate-700 hover:bg-slate-100 border border-slate-200 flex items-center gap-1.5 cursor-pointer"
                >
                  <Volume2 className="w-3.5 h-3.5 text-orange-500" />
                  <span>Nghe Guitar</span>
                </button>
                <button
                  onClick={() => soundEngine.playChord(selectedChord, 'piano')}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-white text-slate-700 hover:bg-slate-100 border border-slate-200 flex items-center gap-1.5 cursor-pointer"
                >
                  <Volume2 className="w-3.5 h-3.5 text-blue-500" />
                  <span>Nghe Piano</span>
                </button>
                <button
                  onClick={() => setSelectedChord(null)}
                  className="text-xs text-slate-400 hover:text-slate-600 px-2"
                >
                  Đóng
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT 2: SHEET NOTATION (MusicXML) */}
      {activeTab === 'sheet' && song.sheetMeasures && (
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                Bản Ký Âm Nhạc Phổ (Sheet Music)
              </h3>
              <p className="text-xs text-slate-500">
                Độ phân giải chuẩn A4, hiển thị khuôn nhạc 5 dòng, khóa Sol, hợp âm và nốt nhạc giai điệu.
              </p>
            </div>
            <button
              onClick={() => window.print()}
              className="px-3 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>In Bản Phổ Này</span>
            </button>
          </div>

          {/* Interactive Music Staff SVG Visualizer */}
          <div className="overflow-x-auto p-4 bg-amber-50/30 rounded-xl border border-amber-200/50">
            <div className="min-w-[700px] space-y-8">
              {song.sheetMeasures.map((measure) => (
                <div key={measure.measureNumber} className="relative bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-400">
                      Ô nhịp {measure.measureNumber}
                    </span>
                    <span className="text-sm font-extrabold text-orange-600">
                      {measure.chords.map(c => transposeChord(c, transpose)).join(' - ')}
                    </span>
                  </div>

                  {/* 5 Staff Lines */}
                  <div className="relative h-24 flex items-center justify-between border-l-2 border-r-2 border-slate-800 px-8">
                    <div className="absolute inset-x-0 top-3 h-0.5 bg-slate-300" />
                    <div className="absolute inset-x-0 top-7 h-0.5 bg-slate-300" />
                    <div className="absolute inset-x-0 top-11 h-0.5 bg-slate-300" />
                    <div className="absolute inset-x-0 top-15 h-0.5 bg-slate-300" />
                    <div className="absolute inset-x-0 top-19 h-0.5 bg-slate-300" />

                    {/* Treble Clef mark */}
                    {measure.measureNumber === 1 && (
                      <span className="font-serif text-3xl font-bold text-slate-800 -mt-2">𝄞</span>
                    )}

                    {/* Notes in measure */}
                    {measure.notes.map((note, noteIdx) => (
                      <button
                        key={noteIdx}
                        onClick={() => soundEngine.playNote(440, 0.6, selectedInstrument)}
                        className="group relative flex flex-col items-center hover:scale-110 transition-transform cursor-pointer"
                      >
                        <div className="w-4 h-3 rounded-full bg-slate-900 group-hover:bg-orange-600 transition-colors shadow-xs" />
                        <span className="text-xs font-bold text-slate-700 mt-2 font-sans">
                          {note.lyric || note.pitch}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {note.duration}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 3: VIRTUAL INSTRUMENTS (Guitar Fretboard & Piano Keys) */}
      {activeTab === 'instruments' && (
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                Nhạc Cụ Trực Quan & Mô Phỏng Âm Thanh
              </h3>
              <p className="text-xs text-slate-500">
                Thử nghiệm thế bấm guitar và phím piano trực quan kèm âm thanh mẫu Web Audio chuẩn xác.
              </p>
            </div>

            {/* Instrument selector */}
            <div className="flex gap-1 bg-slate-100 p-1 rounded-xl">
              {(['guitar', 'piano', 'organ'] as const).map((inst) => (
                <button
                  key={inst}
                  onClick={() => setSelectedInstrument(inst)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-colors cursor-pointer ${
                    selectedInstrument === inst
                      ? 'bg-orange-500 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {inst}
                </button>
              ))}
            </div>
          </div>

          {/* Interactive Piano / Organ Keyboard (2 octaves) */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Bàn Phím Piano & Organ (Click để nghe nốt)
            </h4>
            <div className="flex justify-center overflow-x-auto p-4 bg-slate-900 rounded-2xl shadow-inner">
              <div className="relative flex select-none">
                {[
                  { note: 'C4', isBlack: false, freq: 261.63 },
                  { note: 'C#4', isBlack: true, freq: 277.18 },
                  { note: 'D4', isBlack: false, freq: 293.66 },
                  { note: 'D#4', isBlack: true, freq: 311.13 },
                  { note: 'E4', isBlack: false, freq: 329.63 },
                  { note: 'F4', isBlack: false, freq: 349.23 },
                  { note: 'F#4', isBlack: true, freq: 369.99 },
                  { note: 'G4', isBlack: false, freq: 392.00 },
                  { note: 'G#4', isBlack: true, freq: 415.30 },
                  { note: 'A4', isBlack: false, freq: 440.00 },
                  { note: 'A#4', isBlack: true, freq: 466.16 },
                  { note: 'B4', isBlack: false, freq: 493.88 },
                  { note: 'C5', isBlack: false, freq: 523.25 },
                  { note: 'C#5', isBlack: true, freq: 554.37 },
                  { note: 'D5', isBlack: false, freq: 587.33 },
                  { note: 'D#5', isBlack: true, freq: 622.25 },
                  { note: 'E5', isBlack: false, freq: 659.25 },
                ].map((keyItem, index) => {
                  if (keyItem.isBlack) {
                    return (
                      <button
                        key={keyItem.note}
                        onClick={() => soundEngine.playNote(keyItem.freq, 0.8, selectedInstrument)}
                        aria-label={`Phím đen ${keyItem.note}`}
                        className="w-6 sm:w-7 h-24 bg-slate-800 hover:bg-slate-700 text-white text-[10px] rounded-b-md z-10 -mx-3 sm:-mx-3.5 shadow-md flex items-end justify-center pb-2 cursor-pointer active:bg-orange-500"
                      >
                        {keyItem.note}
                      </button>
                    );
                  }
                  return (
                    <button
                      key={keyItem.note}
                      onClick={() => soundEngine.playNote(keyItem.freq, 0.8, selectedInstrument)}
                      aria-label={`Phím trắng ${keyItem.note}`}
                      className="w-9 sm:w-11 h-40 bg-white hover:bg-slate-100 text-slate-800 text-xs font-semibold rounded-b-lg border-r border-slate-300 shadow-sm flex items-end justify-center pb-3 cursor-pointer active:bg-orange-100"
                    >
                      {keyItem.note}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Interactive Guitar Fretboard */}
          <div className="space-y-3 pt-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Cần Đàn Guitar (Guitar Fretboard - 5 Ngăn Đầu)
            </h4>
            <div className="bg-amber-950 p-4 sm:p-6 rounded-2xl overflow-x-auto shadow-inner text-amber-100">
              <div className="min-w-[600px] border-l-4 border-amber-200">
                {/* 6 strings */}
                {[
                  { name: 'E4', stringNum: 1 },
                  { name: 'B3', stringNum: 2 },
                  { name: 'G3', stringNum: 3 },
                  { name: 'D3', stringNum: 4 },
                  { name: 'A2', stringNum: 5 },
                  { name: 'E2', stringNum: 6 },
                ].map((s) => (
                  <div key={s.stringNum} className="relative flex items-center h-8 border-b border-amber-700/60">
                    <span className="w-8 text-xs font-bold text-amber-300 font-mono">
                      {s.name}
                    </span>
                    <div className="flex-1 flex justify-between pr-4">
                      {[0, 1, 2, 3, 4, 5].map((fret) => (
                        <button
                          key={fret}
                          onClick={() => soundEngine.playNote(150 + fret * 20 + s.stringNum * 35, 1.0, 'guitar')}
                          className="w-12 h-6 border-r-2 border-amber-500/80 hover:bg-amber-800/40 rounded flex items-center justify-center text-[10px] text-amber-400/80 font-mono cursor-pointer"
                        >
                          {fret === 0 ? 'Buông' : `N${fret}`}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Recording & Practice Tool: Microphone Voice / Guitar Recorder */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
            <Mic className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-800">
              Thu Âm & Đánh Giá Giọng Hát / Đàn
            </h4>
            <p className="text-xs text-slate-500">
              Ghi âm trực tiếp bằng microphone trình duyệt để nghe lại và tự chỉnh cao độ, nhịp điệu.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {recordedAudioUrl && (
            <audio src={recordedAudioUrl} controls className="h-9 w-48 sm:w-60" />
          )}

          {!isRecording ? (
            <button
              onClick={startRecording}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 shadow-xs cursor-pointer"
            >
              <Mic className="w-4 h-4" />
              <span>Bắt Đầu Thu</span>
            </button>
          ) : (
            <button
              onClick={stopRecording}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-slate-900 hover:bg-black animate-pulse shadow-xs cursor-pointer"
            >
              <Square className="w-4 h-4" />
              <span>Dừng Thu Âm</span>
            </button>
          )}
        </div>
      </div>

    </div>
  );
};

import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Sparkles, 
  ShieldCheck, 
  Music2, 
  Play, 
  ChevronRight, 
  SlidersHorizontal,
  Layers,
  Clock,
  KeyRound,
  Check
} from 'lucide-react';
import { Song, SheetStatus } from '../types';
import { fuzzyMatchVietnamese } from '../utils/musicLogic';

interface SongCatalogProps {
  songs: Song[];
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onSelectSong: (song: Song) => void;
  onOpenAutoSheet: () => void;
}

export const SongCatalog: React.FC<SongCatalogProps> = ({
  songs,
  searchQuery,
  setSearchQuery,
  onSelectSong,
  onOpenAutoSheet,
}) => {
  const [selectedGenre, setSelectedGenre] = useState<string>('all');
  const [selectedRhythm, setSelectedRhythm] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedTone, setSelectedTone] = useState<string>('all');

  // Extract unique filters
  const genres = useMemo(() => {
    const list = Array.from(new Set(songs.map(s => s.genre))).filter(Boolean);
    return ['all', ...list];
  }, [songs]);

  const rhythms = useMemo(() => {
    const list = Array.from(new Set(songs.map(s => s.rhythm))).filter(Boolean);
    return ['all', ...list];
  }, [songs]);

  const tones = useMemo(() => {
    const list = Array.from(new Set(songs.map(s => s.originalKey))).filter(Boolean);
    return ['all', ...list];
  }, [songs]);

  // Filter songs using Vietnamese NFC/NFD accentless search & faceted filters
  const filteredSongs = useMemo(() => {
    return songs.filter((song) => {
      // Search matching (title, composer, artist, tags, lyrics)
      const matchesSearch = 
        fuzzyMatchVietnamese(searchQuery, song.title) ||
        fuzzyMatchVietnamese(searchQuery, song.composer) ||
        fuzzyMatchVietnamese(searchQuery, song.artist) ||
        song.tags.some(t => fuzzyMatchVietnamese(searchQuery, t)) ||
        fuzzyMatchVietnamese(searchQuery, song.rhythm);

      if (!matchesSearch) return false;

      // Faceted filters
      if (selectedGenre !== 'all' && song.genre !== selectedGenre) return false;
      if (selectedRhythm !== 'all' && song.rhythm !== selectedRhythm) return false;
      if (selectedStatus !== 'all' && song.sheetStatus !== selectedStatus) return false;
      if (selectedTone !== 'all' && song.originalKey !== selectedTone) return false;

      return true;
    });
  }, [songs, searchQuery, selectedGenre, selectedRhythm, selectedStatus, selectedTone]);

  // Render sheet status badge
  const renderStatusBadge = (status: SheetStatus, confidence?: number) => {
    switch (status) {
      case 'verified_sheet':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 text-emerald-800">
            <ShieldCheck className="w-3 h-3 text-emerald-600" />
            Bản Ký Âm Chuẩn
          </span>
        );
      case 'ai_generated_sheet':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-purple-100 text-purple-800">
            <Sparkles className="w-3 h-3 text-purple-600" />
            Sheet AI ({confidence}%)
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-amber-100 text-amber-800">
            <Music2 className="w-3 h-3 text-amber-600" />
            Hợp Âm & Lời
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Hero Banner: Đa Nguồn & Chuẩn Hóa */}
      <div className="relative overflow-hidden bg-gradient-to-r from-orange-600 via-amber-600 to-rose-600 rounded-3xl p-6 sm:p-10 text-white shadow-lg">
        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold tracking-wide">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Nâng Cấp Toàn Diện Góc Hợp Âm v2.5.0</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight">
            Kho Hợp Âm & Ký Âm Sheet Đa Nguồn Chuẩn Xác
          </h1>
          <p className="text-sm sm:text-base text-orange-100 leading-relaxed">
            Tra cứu chuẩn hóa Unicode tiếng Việt (NFC/NFD, không dấu), căn hợp âm chuẩn xác trên lời, tích hợp AI tự tạo sheet khi thiếu, và phát lại trực quan trên Guitar, Piano, Organ.
          </p>
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={onOpenAutoSheet}
              className="px-5 py-2.5 rounded-xl font-bold text-sm bg-white text-orange-700 hover:bg-orange-50 active:scale-95 transition-all shadow-md flex items-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-orange-600" />
              <span>Tạo Sheet Bằng AI (P2 Engine)</span>
            </button>
            <div className="text-xs text-orange-100 font-medium">
              Đã số hóa {songs.length} bài hát chọn lọc • 100% Miễn phí
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar Section */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        
        {/* Main Search Input */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Tìm theo tên bài hát (e.g. Diễm Xưa, Cơn Mưa Ngang Qua), nhạc sĩ, ca sĩ..."
            className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-orange-500 focus:ring-2 focus:ring-orange-200 outline-none transition-all text-slate-800"
          />
        </div>

        {/* Faceted Filters Row */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          
          {/* Status Filter */}
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-slate-500">Trạng thái:</span>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="bg-slate-100 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 font-medium outline-none focus:ring-1 focus:ring-orange-400"
            >
              <option value="all">Tất cả ({songs.length})</option>
              <option value="verified_sheet">Bản ký âm xác minh</option>
              <option value="ai_generated_sheet">Sheet AI tự động</option>
              <option value="chord_lyrics_only">Hợp âm & Lời</option>
            </select>
          </div>

          {/* Genre Filter */}
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-slate-500">Thể loại:</span>
            <select
              value={selectedGenre}
              onChange={(e) => setSelectedGenre(e.target.value)}
              className="bg-slate-100 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 font-medium outline-none focus:ring-1 focus:ring-orange-400"
            >
              <option value="all">Tất cả thể loại</option>
              {genres.filter(g => g !== 'all').map(g => (
                <option key={g} value={g}>{g}</option>
              ))}
            </select>
          </div>

          {/* Rhythm Filter */}
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-slate-500">Điệu:</span>
            <select
              value={selectedRhythm}
              onChange={(e) => setSelectedRhythm(e.target.value)}
              className="bg-slate-100 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 font-medium outline-none focus:ring-1 focus:ring-orange-400"
            >
              <option value="all">Tất cả điệu</option>
              {rhythms.filter(r => r !== 'all').map(r => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
          </div>

          {/* Tone Filter */}
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-slate-500">Tone:</span>
            <select
              value={selectedTone}
              onChange={(e) => setSelectedTone(e.target.value)}
              className="bg-slate-100 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 font-medium outline-none focus:ring-1 focus:ring-orange-400"
            >
              <option value="all">Tất cả tone</option>
              {tones.filter(t => t !== 'all').map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          {/* Clear filters button if active */}
          {(selectedGenre !== 'all' || selectedRhythm !== 'all' || selectedStatus !== 'all' || selectedTone !== 'all' || searchQuery) && (
            <button
              onClick={() => {
                setSelectedGenre('all');
                setSelectedRhythm('all');
                setSelectedStatus('all');
                setSelectedTone('all');
                setSearchQuery('');
              }}
              className="ml-auto text-xs font-semibold text-orange-600 hover:text-orange-700 underline"
            >
              Đặt lại bộ lọc
            </button>
          )}

        </div>
      </div>

      {/* Song Cards Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs font-semibold text-slate-500 px-1">
          <span>Tìm thấy {filteredSongs.length} bài hát phù hợp</span>
          <span>Sắp xếp: Phổ biến nhất</span>
        </div>

        {filteredSongs.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 p-8 space-y-4">
            <div className="w-14 h-14 rounded-full bg-orange-50 text-orange-600 flex items-center justify-center mx-auto">
              <Search className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-800">
              Không tìm thấy bài hát nào khớp với từ khóa
            </h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Bạn có thể sử dụng Auto Sheet Engine (P2) để tự động tìm nguồn hoặc phân tích audio/YouTube và tạo bản sheet mới ngay tức thì!
            </p>
            <button
              onClick={onOpenAutoSheet}
              className="inline-flex items-center gap-2 px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold rounded-xl transition-colors"
            >
              <Sparkles className="w-4 h-4" />
              <span>Tạo Sheet Cho Bài Này</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredSongs.map((song) => (
              <div
                key={song.id}
                onClick={() => onSelectSong(song)}
                className="group bg-white p-5 rounded-2xl border border-slate-200 hover:border-orange-400 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
              >
                <div className="space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-bold text-slate-900 group-hover:text-orange-600 transition-colors text-base line-clamp-1">
                      {song.title}
                    </h3>
                    <span className="px-2 py-0.5 rounded-md text-xs font-mono font-bold bg-slate-100 text-slate-700 shrink-0">
                      {song.originalKey}
                    </span>
                  </div>

                  <p className="text-xs text-slate-500">
                    Sáng tác: <strong className="text-slate-700">{song.composer}</strong> • Thể hiện:{' '}
                    <span className="text-slate-700">{song.artist}</span>
                  </p>

                  <div className="flex items-center gap-2 pt-1">
                    {renderStatusBadge(song.sheetStatus, song.confidenceScore)}
                    <span className="text-[11px] text-slate-500 font-medium">
                      {song.rhythm}
                    </span>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1 pt-1">
                    {song.tags.slice(0, 3).map((tag, idx) => (
                      <span key={idx} className="text-[10px] px-2 py-0.5 rounded-md bg-slate-50 text-slate-600 border border-slate-100">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400 group-hover:text-orange-600 font-semibold">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{song.tempo} BPM</span>
                  </span>
                  <div className="flex items-center gap-1">
                    <span>Xem Hợp Âm & Luyện</span>
                    <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};

import React, { useState } from 'react';
import { BookOpen, Volume2, Search, Layers, Guitar, Music } from 'lucide-react';
import { CHORD_DICTIONARY } from '../data/chordData';
import { soundEngine, getChordNotes } from '../utils/musicLogic';

export const ChordDictionary: React.FC = () => {
  const [selectedRoot, setSelectedRoot] = useState<string>('all');
  const [selectedChordName, setSelectedChordName] = useState<string>('C');
  const [instrument, setInstrument] = useState<'guitar' | 'piano'>('guitar');

  const chordList = Object.keys(CHORD_DICTIONARY);
  const activeChord = CHORD_DICTIONARY[selectedChordName] || CHORD_DICTIONARY['C'];

  const filteredChords = chordList.filter(name => {
    if (selectedRoot === 'all') return true;
    return name.startsWith(selectedRoot);
  });

  const roots = ['all', 'C', 'D', 'E', 'F', 'G', 'A', 'B'];

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 text-blue-700 text-xs font-bold">
          <BookOpen className="w-3.5 h-3.5" />
          <span>Tra Cứu Hợp Âm Chuẩn Xác</span>
        </div>
        <h2 className="text-2xl font-extrabold text-slate-900">
          Từ Điển Hợp Âm Guitar & Phím Đàn Piano
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 max-w-2xl">
          Xem trực quan thế bấm các ngăn guitar, phím đàn piano và nghe mẫu âm thanh được tổng hợp qua Web Audio API không phụ thuộc file ngoài.
        </p>
      </div>

      {/* Root Filter Buttons */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center gap-2">
        <span className="text-xs font-bold text-slate-500 mr-2">Nốt chủ âm:</span>
        {roots.map(root => (
          <button
            key={root}
            onClick={() => setSelectedRoot(root)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
              selectedRoot === root
                ? 'bg-orange-500 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {root === 'all' ? 'Tất cả' : root}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Chord Selector List */}
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Danh sách ({filteredChords.length} hợp âm)
          </h3>
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-[420px] overflow-y-auto pr-1">
            {filteredChords.map(name => (
              <button
                key={name}
                onClick={() => {
                  setSelectedChordName(name);
                  soundEngine.playChord(name, instrument);
                }}
                className={`py-3 rounded-xl font-extrabold text-sm transition-all cursor-pointer ${
                  selectedChordName === name
                    ? 'bg-orange-600 text-white shadow-md shadow-orange-500/20 scale-102'
                    : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-100'
                }`}
              >
                {name}
              </button>
            ))}
          </div>
        </div>

        {/* Chord Diagram & Sound Preview */}
        <div className="lg:col-span-2 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-orange-500 text-white font-black text-2xl flex items-center justify-center shadow-md shadow-orange-500/20">
                {activeChord.name}
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  Hợp âm {activeChord.name} ({activeChord.quality})
                </h3>
                <p className="text-xs text-slate-500">
                  Cấu tạo nốt: <strong>{activeChord.notes.join(' - ')}</strong>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => soundEngine.playChord(activeChord.name, 'guitar')}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200 flex items-center gap-1.5 cursor-pointer"
              >
                <Volume2 className="w-4 h-4 text-amber-600" />
                <span>Nghe Guitar</span>
              </button>
              <button
                onClick={() => soundEngine.playChord(activeChord.name, 'piano')}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-blue-50 text-blue-900 hover:bg-blue-100 border border-blue-200 flex items-center gap-1.5 cursor-pointer"
              >
                <Volume2 className="w-4 h-4 text-blue-600" />
                <span>Nghe Piano</span>
              </button>
            </div>
          </div>

          {/* Visual Guitar Box */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <Guitar className="w-4 h-4 text-orange-500" />
              <span>Thế bấm Guitar (6 Dây từ Thấp đến Cao)</span>
            </h4>
            <div className="bg-amber-950 p-5 rounded-2xl text-amber-100 font-mono text-xs shadow-inner">
              <div className="grid grid-cols-6 gap-2 text-center pb-2 border-b border-amber-700/60 font-bold text-amber-300">
                <span>E (6)</span>
                <span>A (5)</span>
                <span>D (4)</span>
                <span>G (3)</span>
                <span>B (2)</span>
                <span>E (1)</span>
              </div>
              <div className="grid grid-cols-6 gap-2 text-center pt-3">
                {activeChord.guitarFingering.frets.map((fret, i) => (
                  <div key={i} className="flex flex-col items-center gap-1">
                    <span className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                      fret === -1
                        ? 'bg-rose-950 text-rose-400 border border-rose-800'
                        : fret === 0
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-amber-500 text-slate-950 shadow-sm'
                    }`}>
                      {fret === -1 ? 'X' : fret === 0 ? 'O' : fret}
                    </span>
                    <span className="text-[10px] text-amber-400/80">
                      {fret === -1 ? 'Tắt' : fret === 0 ? 'Buông' : `Ngăn ${fret}`}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Notes decomposition */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <span className="text-xs text-slate-500">
              Nhạc lý: Hợp âm {activeChord.name} gồm các quãng cơ bản tạo nên hòa thanh đặc trưng.
            </span>
            <span className="text-xs font-bold text-slate-700">
              {activeChord.notes.length} Nốt cấu thành
            </span>
          </div>

        </div>

      </div>

    </div>
  );
};

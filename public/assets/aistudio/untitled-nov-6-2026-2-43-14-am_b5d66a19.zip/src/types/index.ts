export type SheetStatus = 
  | 'verified_sheet'     // Bản ký âm chuẩn xác minh
  | 'ai_generated_sheet' // Bản phổ AI tạo tự động từ audio/MIDI
  | 'chord_lyrics_only'  // Chỉ hợp âm và lời chuẩn
  | 'pending_analysis';  // Đang trong hàng đợi phân tích

export type UserRole = 'guest' | 'member' | 'admin';

export interface SheetMeasure {
  measureNumber: number;
  timeSignature?: string;
  chords: string[];
  notes: {
    pitch: string; // e.g., 'C4', 'E4', 'G4', 'A4'
    duration: string; // 'quarter', 'eighth', 'half', 'whole'
    lyric?: string;
    isRest?: boolean;
  }[];
}

export interface Song {
  id: string;
  title: string;
  composer: string; // Tác giả
  artist: string;   // Nghệ sĩ / Ca sĩ thể hiện
  originalKey: string; // e.g., 'Am', 'C', 'G'
  tempo: number;    // BPM
  timeSignature: string; // e.g., '4/4', '3/4', '6/8'
  genre: string;    // Thể loại (Nhạc Trịnh, Trữ Tình, Pop Ballad, Indie, Bolero, Jazz...)
  rhythm: string;   // Điệu nhạc (Slow Rock, Ballad, Bolero, Valse, Disco...)
  youtubeId?: string; // YouTube video ID for embed and sync
  sheetStatus: SheetStatus;
  confidenceScore?: number; // e.g., 95 (%) for AI generated sheets
  provenance: {
    origin: string; // Nguồn gốc
    license: string; // Quyền sử dụng
    version: string;
    verifiedBy?: string;
    lastUpdated: string;
  };
  lyricsWithChords: string; // Format with bracketed chords e.g., "[Am] Mưa vẫn mưa bay [Dm] trên tầng tháp cổ"
  sheetMeasures?: SheetMeasure[];
  tags: string[];
}

export interface ChordDetail {
  name: string;
  root: string;
  quality: string;
  notes: string[]; // ['C', 'E', 'G']
  pianoKeys: number[]; // MIDI note numbers or key indices
  guitarFingering: {
    frets: number[]; // 6 strings from low E to high E, e.g. [-1, 3, 2, 0, 1, 0] for C
    fingers: number[]; // 0 for open, 1-4 for index to pinky, -1 for mute
    barreAt?: number;
  };
}

export interface AutoSheetJob {
  id: string;
  songTitle: string;
  artist: string;
  sourceType: 'audio' | 'youtube' | 'midi' | 'pdf';
  sourceUrl?: string;
  status: 'queued' | 'processing' | 'verifying' | 'completed' | 'failed';
  currentStep: number;
  totalSteps: number;
  progressPercent: number;
  stepDescription: string;
  confidenceScore: number;
  detectedKey: string;
  detectedTempo: number;
  isAiGenerated: boolean;
  createdAt: string;
  errorLog?: string;
}

export interface PracticeSettings {
  transpose: number; // Semitones: -12 to +12
  capo: number; // 0 to 11
  fontSize: number; // Percentage or pt
  autoScrollSpeed: number; // 1 to 10
  isAutoScrolling: boolean;
  activeInstrument: 'guitar' | 'piano' | 'organ';
  metronomeBpm: number;
  metronomeActive: boolean;
  timeSignature: string;
  playbackSpeed: number; // 0.5, 0.75, 1, 1.25, 1.5
  loopStart: number | null; // Seconds
  loopEnd: number | null;   // Seconds
}

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizeVietnamese,
  fuzzyMatchVietnamese,
  transposeChord,
  transposeLyricsText,
  calculateCapo,
  getChordNotes,
  parseLyricsLine
} from './musicLogic';

test('normalizeVietnamese strips diacritics and handles D/d correctly', () => {
  assert.equal(normalizeVietnamese('Diễm Xưa'), 'diem xua');
  assert.equal(normalizeVietnamese('Đoản Khúc Lam Giang'), 'doan khuc lam giang');
  assert.equal(normalizeVietnamese('HỢP ÂM VIỆT'), 'hop am viet');
});

test('fuzzyMatchVietnamese matches accentless queries with accented titles', () => {
  assert.equal(fuzzyMatchVietnamese('diem xua', 'Diễm Xưa - Trịnh Công Sơn'), true);
  assert.equal(fuzzyMatchVietnamese('con mua ngang qua', 'Cơn Mưa Ngang Qua'), true);
  assert.equal(fuzzyMatchVietnamese('nang tho hoang dung', 'Nàng Thơ - Hoàng Dũng'), true);
  assert.equal(fuzzyMatchVietnamese('khong lien quan', 'Diễm Xưa'), false);
});

test('transposeChord handles simple and slash chords correctly', () => {
  // Simple transpositions
  assert.equal(transposeChord('C', 2), 'D');
  assert.equal(transposeChord('Am', 2), 'Bm');
  assert.equal(transposeChord('G', -2), 'F');
  assert.equal(transposeChord('Em', 1), 'Fm');

  // Seventh & complex qualities
  assert.equal(transposeChord('Cmaj7', 2), 'Dmaj7');
  assert.equal(transposeChord('Bm7b5', 1), 'Cm7b5');

  // Slash chords
  assert.equal(transposeChord('D/F#', 2), 'E/G#');
  assert.equal(transposeChord('C/E', -2), 'Bb/D');
});

test('transposeLyricsText updates all bracketed chords in verse', () => {
  const original = '[Am] Mưa vẫn mưa bay trên [Dm] tầng tháp [E7] cổ';
  const transposed = transposeLyricsText(original, 2);
  assert.equal(transposed, '[Bm] Mưa vẫn mưa bay trên [Em] tầng tháp [F#7] cổ');
});

test('calculateCapo returns expected fret position', () => {
  // If song is in D and we play in C, capo is 2
  assert.equal(calculateCapo('D', 'C'), 2);
  // If song is in E and we play in C, capo is 4
  assert.equal(calculateCapo('E', 'C'), 4);
  // If song is in C and we play in C, capo is 0
  assert.equal(calculateCapo('C', 'C'), 0);
});

test('getChordNotes extracts accurate triads', () => {
  assert.deepEqual(getChordNotes('C'), ['C', 'E', 'G']);
  assert.deepEqual(getChordNotes('Am'), ['A', 'C', 'E']);
  assert.deepEqual(getChordNotes('G'), ['G', 'B', 'D']);
});

test('parseLyricsLine extracts chord anchors and text segments', () => {
  const line = '[Am] Mưa vẫn mưa bay [Dm] trên tầng tháp cổ';
  const parsed = parseLyricsLine(line);
  assert.ok(parsed.segments.length >= 2);
  assert.equal(parsed.segments[0].chord, 'Am');
  assert.ok(parsed.segments[0].text.includes('Mưa vẫn mưa bay'));
});

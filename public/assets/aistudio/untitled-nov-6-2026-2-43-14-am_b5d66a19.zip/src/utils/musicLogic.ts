/**
 * Góc Hợp Âm - Pure Music Logic & Audio Engine
 * Handles Vietnamese search normalization, chord transposition, Capo calculation,
 * and Web Audio synthesis for guitar, piano & metronome.
 */

const CHROMATIC_SCALE_SHARPS = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const CHROMATIC_SCALE_FLATS  = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B'];

/**
 * Normalizes Vietnamese text by standardizing Unicode (NFC),
 * removing diacritical marks, and lowercasing for fuzzy & accentless search.
 */
export function normalizeVietnamese(str: string): string {
  if (!str) return '';
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove diacritics
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .normalize('NFC')
    .toLowerCase()
    .trim();
}

/**
 * Checks if search query matches target text using Vietnamese accent-insensitive fuzzy search.
 */
export function fuzzyMatchVietnamese(query: string, target: string): boolean {
  if (!query) return true;
  if (!target) return false;
  
  const normQuery = normalizeVietnamese(query);
  const normTarget = normalizeVietnamese(target);
  
  // Direct inclusion
  if (normTarget.includes(normQuery)) return true;
  
  // Word by word matching
  const queryTokens = normQuery.split(/\s+/).filter(Boolean);
  return queryTokens.every(token => normTarget.includes(token));
}

/**
 * Note to semitone mapping (relative to C = 0)
 */
const NOTE_TO_SEMITONE: Record<string, number> = {
  'C': 0, 'B#': 0,
  'C#': 1, 'Db': 1,
  'D': 2,
  'D#': 3, 'Eb': 3,
  'E': 4, 'Fb': 4,
  'F': 5, 'E#': 5,
  'F#': 6, 'Gb': 6,
  'G': 7,
  'G#': 8, 'Ab': 8,
  'A': 9,
  'A#': 10, 'Bb': 10,
  'B': 11, 'Cb': 11,
};

/**
 * Transpose a single root note by semitones
 */
export function transposeNote(note: string, semitones: number, preferFlats = false): string {
  const baseVal = NOTE_TO_SEMITONE[note];
  if (baseVal === undefined) return note;

  const targetVal = ((baseVal + semitones) % 12 + 12) % 12;
  const scale = preferFlats ? CHROMATIC_SCALE_FLATS : CHROMATIC_SCALE_SHARPS;
  return scale[targetVal];
}

/**
 * Transpose a full chord symbol (e.g. "Am7", "C#dim", "F#m/A", "Bb(add9)")
 */
export function transposeChord(chord: string, semitones: number): string {
  if (!chord || semitones === 0) return chord;
  
  // Handle slash chords like C/E, G/B
  if (chord.includes('/')) {
    const parts = chord.split('/');
    return `${transposeChord(parts[0], semitones)}/${transposeChord(parts[1], semitones)}`;
  }

  // Regex to extract root note: e.g. "C#", "Bb", "A"
  const match = chord.match(/^([A-G][#b]?)(.*)$/);
  if (!match) return chord;

  const root = match[1];
  const quality = match[2];

  // In music theory, Bb, Eb, Ab, F are preferred in flat keys, and when transposing down from C/F
  const preferFlats = root.includes('b') || ['F', 'Bb', 'Eb', 'Ab'].includes(root) || (root === 'C' && semitones < 0);
  const newRoot = transposeNote(root, semitones, preferFlats);

  return `${newRoot}${quality}`;
}

/**
 * Transpose full lyrics string containing bracketed chords [Am] [G]
 */
export function transposeLyricsText(text: string, semitones: number): string {
  if (!text || semitones === 0) return text;
  return text.replace(/\[([A-G][#b]?[^\]]*)\]/g, (_, chord) => {
    return `[${transposeChord(chord, semitones)}]`;
  });
}

/**
 * Calculate Capo fret recommendation for guitar
 * e.g., if target is Eb, playing with C shapes requires Capo at fret 3
 */
export function calculateCapo(songKey: string, preferredEasyKey = 'C'): number {
  const songRoot = songKey.replace(/m.*/, '');
  const easyRoot = preferredEasyKey.replace(/m.*/, '');

  const songSemitone = NOTE_TO_SEMITONE[songRoot] ?? 0;
  const easySemitone = NOTE_TO_SEMITONE[easyRoot] ?? 0;

  let fret = (songSemitone - easySemitone + 12) % 12;
  return fret;
}

/**
 * Frequency calculation for musical notes (A4 = 440 Hz)
 */
export function noteToFrequency(noteName: string): number {
  // e.g. "A4", "C#3", "Eb5"
  const match = noteName.match(/^([A-G][#b]?)(\d)$/);
  if (!match) return 440;

  const note = match[1];
  const octave = parseInt(match[2], 10);
  const semitone = NOTE_TO_SEMITONE[note] ?? 0;
  
  // MIDI number: C4 is 60, A4 is 69
  const midi = 12 + octave * 12 + semitone;
  return 440 * Math.pow(2, (midi - 69) / 12);
}

/**
 * Sound Synthesizer via Web Audio API
 * Generates realistic acoustic sounds without external mp3s
 */
class SoundEngine {
  private ctx: AudioContext | null = null;

  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  /**
   * Play a note with instrument timbre (piano or acoustic guitar)
   */
  playNote(frequency: number, duration = 1.0, instrument: 'piano' | 'guitar' | 'organ' = 'piano') {
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    if (instrument === 'piano') {
      osc.type = 'triangle';
      // Piano envelope: sharp attack, gentle decay
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.35, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    } else if (instrument === 'guitar') {
      osc.type = 'sawtooth';
      // Plucked string envelope
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.28, now + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration * 0.85);
    } else { // organ
      osc.type = 'sine';
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.3, now + 0.05);
      gain.gain.setValueAtTime(0.25, now + duration * 0.8);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    }

    osc.frequency.setValueAtTime(frequency, now);

    // Filter to warm up sound
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(instrument === 'guitar' ? 1800 : 2500, now);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + duration + 0.1);
  }

  /**
   * Play a full chord arpeggiated or strummed
   */
  playChord(chordName: string, instrument: 'piano' | 'guitar' | 'organ' = 'guitar') {
    const ctx = this.getContext();
    if (!ctx) return;

    const notes = getChordNotes(chordName);
    const baseOctave = 3;

    notes.forEach((note, index) => {
      const octave = baseOctave + Math.floor(index / 3);
      const freq = noteToFrequency(`${note}${octave}`);
      const delay = instrument === 'guitar' ? index * 0.045 : index * 0.02; // Strum feel
      
      setTimeout(() => {
        this.playNote(freq, 1.8, instrument);
      }, delay * 1000);
    });
  }

  /**
   * Metronome click sound
   */
  playMetronomeTick(isAccent: boolean) {
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(isAccent ? 1200 : 800, now);

    gain.gain.setValueAtTime(0.35, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.06);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.07);
  }
}

export const soundEngine = new SoundEngine();

/**
 * Returns basic triad/seventh notes for a chord name
 */
export function getChordNotes(chord: string): string[] {
  const match = chord.match(/^([A-G][#b]?)(.*)$/);
  if (!match) return ['C', 'E', 'G'];

  const root = match[1];
  const qual = match[2].toLowerCase();

  const rootVal = NOTE_TO_SEMITONE[root] ?? 0;
  let intervals = [0, 4, 7]; // Major triad

  if (qual.startsWith('m') && !qual.startsWith('maj')) {
    intervals = [0, 3, 7]; // Minor triad
  } else if (qual.includes('dim')) {
    intervals = [0, 3, 6]; // Diminished
  } else if (qual.includes('aug')) {
    intervals = [0, 4, 8]; // Augmented
  } else if (qual.includes('sus4')) {
    intervals = [0, 5, 7]; // Sus4
  } else if (qual.includes('7') && !qual.includes('maj7')) {
    intervals = qual.startsWith('m') ? [0, 3, 7, 10] : [0, 4, 7, 10]; // Dominant or m7
  } else if (qual.includes('maj7')) {
    intervals = [0, 4, 7, 11]; // Maj7
  }

  return intervals.map(semitone => {
    const idx = (rootVal + semitone) % 12;
    return CHROMATIC_SCALE_SHARPS[idx];
  });
}

/**
 * Parsed chord line structure for aligned presentation
 */
export interface LyricLine {
  segments: {
    chord?: string;
    text: string;
  }[];
}

/**
 * Parses lyric string with inline chords e.g. "[Am] Mưa vẫn mưa bay [Dm] trên tầng tháp cổ"
 * into structured chunks for precision alignment.
 */
export function parseLyricsLine(line: string): LyricLine {
  const segments: LyricLine['segments'] = [];
  const regex = /\[([A-G][#b]?[^\]]*)\]/g;
  
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(line)) !== null) {
    const chord = match[1];
    const matchIndex = match.index;

    // Any text preceding this chord
    if (matchIndex > lastIndex) {
      const text = line.substring(lastIndex, matchIndex);
      if (segments.length > 0 && !segments[segments.length - 1].text) {
        segments[segments.length - 1].text = text;
      } else {
        segments.push({ text });
      }
    }

    lastIndex = regex.lastIndex;
    segments.push({ chord, text: '' });
  }

  // Trailing text
  if (lastIndex < line.length) {
    const trailingText = line.substring(lastIndex);
    if (segments.length > 0 && !segments[segments.length - 1].text) {
      segments[segments.length - 1].text = trailingText;
    } else {
      segments.push({ text: trailingText });
    }
  }

  if (segments.length === 0) {
    segments.push({ text: line });
  }

  return { segments };
}

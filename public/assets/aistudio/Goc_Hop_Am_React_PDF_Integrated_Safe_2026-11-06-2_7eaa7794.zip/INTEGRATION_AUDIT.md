# Góc Hợp Âm — biên bản tích hợp thư viện PDF (06/11/2026)

## Nguồn và phạm vi
- File gốc: `untitled-nov-6-2026-2-43-14-am.zip` (Google AI Studio React + Vite).
- Đây **không** phải checkout mã nguồn Sites dự án `appgprj_6ae93d0e853c8191bc61999c745a657c`.
- Website Sites `https://goc-hop-am.onwardcrust.chatgpt.site/` **không bị sửa, ghi đè hoặc triển khai lại**.
- GitHub `duyuyd/goc-hop-am` chứa phần mobile cũ; PR #5 là module PDF trên nhánh nháp. Không merge PR vào Sites.
- WebsitePublisher chỉ có project `31999` / `project31999.websitepublisher.ai`, không liên quan Sites. Không xuất bản qua WebsitePublisher.

## Đã tích hợp vào bản React trong ZIP này
1. Thêm mục `Sheet PDF` trong thanh điều hướng desktop và Android.
2. Thêm nút `Tìm Sheet PDF` ngay ở trang xem bài, mang theo tên bài qua trang tra cứu.
3. Giao diện thư viện PDF responsive: tìm tiếng Việt không dấu, lọc 13 thể loại, 8 website, định dạng và A–Z/Z–A.
4. Danh mục nguồn có **5 PDF trực tiếp** tại Mutopia (đã được TinyFish đọc thành công ngày 06/11/2026) và **6 trang sheet Việt** (chỉ là trang nguồn, chưa lưu PDF).
5. Trình xem PDF có iframe và nút mở/tải tại nguồn. Không sao chép tệp PDF từ site khác.
6. Tra API read-only `https://goc-hop-am.onwardcrust.chatgpt.site/api/catalog?mode=search&q=...` để tìm bài. Nếu API bị chặn CORS thì báo rõ và tiếp tục dùng các nguồn khác.
7. Chỉ xác nhận sheet khớp khi **tên bài và nhạc sĩ** khớp, không ghép theo tiêu đề duy nhất.
8. Cập nhật nhãn của Auto Sheet / báo cáo để hiển thị rõ là bản mô phỏng: chưa có bằng chứng pipeline AI đã phân tích audio hay xác minh độ tin cậy 95%.
9. Giữ bản ZIP GitHub lồng bên trong tại `backups/goc-hop-am-main-original-backup.zip` thay vì trong `public/`, tránh vô tình phát tán dữ liệu backup khi deploy.

## Kiểm thử đã chạy
- `node --experimental-strip-types --test tests/sheetLibrary.test.mjs`: **5/5 pass**.
- TypeScript AST syntax parse: **18 tệp .ts/.tsx, 0 lỗi cú pháp** với TypeScript 5.8.3 sẵn có.
- Quét chuỗi dạng API key / GitHub token / private key trong các tệp text: không phát hiện mẫu thông dụng (không thay thế security audit).
- 5 URL Mutopia đã được công cụ web đọc nội dung bản phổ thành công.
- Chưa chạy `npm run build` / kiểm thử trình duyệt đầu cuối vì môi trường này không cài được dependencies React/Vite (npm install bị timeout).
- Chưa xác minh có thể truy xuất API từ trình duyệt trên host khác: CORS có thể chặn.

## Việc cần có trước khi đưa vào Sites v26+
1. Checkout/khôi phục **đúng mã nguồn Sites v26+** từ phiên Sites/Work có quyền; sao lưu và đánh dấu SHA.
2. So sánh router, trang reader/song, bộ lọc, asset, PDF tồn tại; chuẩn hóa schema rồi port các module `src/data/sheetLibrary.ts` + `src/components/SheetLibrary.tsx` hoặc tính năng tương đương.
3. Xác nhận thay đổi qua build, test trình duyệt Android, SEO và API. Đảm bảo quyền riêng tư trước triển khai.
4. Chỉ triển khai khi sửa đúng source of truth. Không dùng ZIP này thay thế site đang chạy.

## Cảnh báo chức năng
- Nguồn PDF/Trang sheet chỉ là **danh mục đã nhập**, không phải toàn bộ PDF Việt của 8 website.
- Không gắn nhãn “có PDF” cho bài chưa xác minh. Không gọi `window.print()` là xuất khuông nhạc chuẩn từ nốt.
- Bản React gốc dùng `INITIAL_SONGS` mẫu, chưa nối kho bài thành state thực. API chỉ được tra đọc trong thư viện PDF mới.
- RBAC, báo cáo nghiệm thu và các số phần trăm trong mã gốc có yếu tố mô phỏng. Không dùng làm kết quả kiểm thử sản xuất.
- Không có thay đổi trên WebsitePublisher, GitHub `main`, hoặc Sites.

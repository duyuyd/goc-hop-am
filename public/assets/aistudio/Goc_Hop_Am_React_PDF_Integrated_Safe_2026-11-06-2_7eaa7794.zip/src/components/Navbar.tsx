import React, { useState } from 'react';
import { 
  Music, 
  Search, 
  Menu, 
  X, 
  Sparkles, 
  Sliders, 
  BookOpen, 
  ShieldCheck, 
  FileCheck, FileMusic, 
  UserCheck, 
  Guitar, 
  Volume2,
  ChevronDown
} from 'lucide-react';
import { UserRole } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  onOpenAutoSheetModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  searchQuery,
  setSearchQuery,
  userRole,
  setUserRole,
  onOpenAutoSheetModal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);

  const navItems = [
    { id: 'catalog', label: 'Kho Bài Hát', icon: Music, badge: 'Đa Nguồn' },
    { id: 'autosheet', label: 'Auto Sheet AI', icon: Sparkles, badge: 'P2 Engine' },
    { id: 'sheet-library', label: 'Sheet PDF', icon: FileMusic, badge: '8 nguồn' },
    { id: 'practice', label: 'Phòng Luyện Tập', icon: Guitar, badge: 'Đa Nhạc Cụ' },
    { id: 'dictionary', label: 'Bảng Hợp Âm', icon: BookOpen },
    { id: 'security', label: 'Bảo Mật & Bản Quyền', icon: ShieldCheck, badge: 'ASVS 5.0' },
    { id: 'report', label: 'Báo Cáo P5', icon: FileCheck },
  ];

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
  };

  const getRoleLabel = (role: UserRole) => {
    switch (role) {
      case 'admin': return 'Quản Trị Viên (Admin)';
      case 'member': return 'Thành Viên (Pro)';
      default: return 'Khách (Guest)';
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200 transition-colors shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo Brand */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => handleNavClick('catalog')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-600 flex items-center justify-center text-white shadow-md shadow-orange-500/20">
              <Music className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-tight text-slate-900">
                  Góc Hợp Âm
                </span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-sm bg-orange-100 text-orange-700 tracking-wider">
                  PRO
                </span>
              </div>
              <p className="text-[11px] text-slate-500 hidden sm:block font-medium">
                Hợp Âm • Sheet Nhạc AI • Luyện Tập Âm Nhạc
              </p>
            </div>
          </div>

          {/* Desktop Search Bar */}
          <div className="hidden lg:flex items-center flex-1 max-w-md mx-6">
            <div className="relative w-full">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Search className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Tìm bài hát, nghệ sĩ, điệu nhạc, hợp âm (NFC, không dấu)..."
                className="w-full pl-9 pr-8 py-2 text-sm bg-slate-100 hover:bg-slate-200/70 focus:bg-white border border-transparent focus:border-orange-500 focus:ring-2 focus:ring-orange-200 rounded-lg text-slate-800 placeholder-slate-400 transition-all outline-none"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  aria-label="Xóa từ khóa tìm kiếm"
                  className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center space-x-1" aria-label="Menu chính">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`px-3 py-2 rounded-lg text-sm font-semibold flex items-center gap-1.5 transition-colors relative ${
                    isActive
                      ? 'text-orange-600 bg-orange-50 font-bold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-orange-600' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className={`text-[10px] px-1 py-0.2 rounded font-semibold ${
                      isActive ? 'bg-orange-200/80 text-orange-800' : 'bg-slate-200/80 text-slate-600'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Buttons */}
          <div className="hidden md:flex items-center space-x-3">
            {/* Quick Auto-Sheet button */}
            <button
              onClick={onOpenAutoSheetModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold text-white bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 shadow-sm shadow-orange-500/20 active:scale-95 transition-all cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Tạo Sheet AI</span>
            </button>

            {/* Role Switcher for RBAC demonstration */}
            <div className="relative">
              <button
                onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg border border-slate-200 transition-colors"
                aria-expanded={roleDropdownOpen}
                aria-label="Chọn vai trò người dùng"
              >
                <UserCheck className="w-3.5 h-3.5 text-slate-500" />
                <span className="capitalize">{userRole}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {roleDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-lg border border-slate-200 py-1.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                  <div className="px-3 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Quyền hạn (RBAC)
                  </div>
                  {(['guest', 'member', 'admin'] as UserRole[]).map((r) => (
                    <button
                      key={r}
                      onClick={() => {
                        setUserRole(r);
                        setRoleDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between ${
                        userRole === r ? 'bg-orange-50 text-orange-600 font-bold' : 'text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <span>{getRoleLabel(r)}</span>
                      {userRole === r && <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Menu Ba Gạch (Mobile Hamburger Button) */}
          <div className="flex md:hidden items-center space-x-2">
            <button
              onClick={onOpenAutoSheetModal}
              className="p-2 text-orange-600 bg-orange-50 hover:bg-orange-100 rounded-lg text-xs"
              aria-label="Tạo Sheet AI nhanh"
            >
              <Sparkles className="w-4 h-4" />
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-700 hover:text-slate-900 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-orange-500 transition-colors"
              aria-label={mobileMenuOpen ? "Đóng menu ba gạch" : "Mở menu ba gạch"}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6 stroke-[2.2]" />
              ) : (
                <Menu className="w-6 h-6 stroke-[2.2]" />
              )}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer Menu (Menu Ba Gạch Navigation Panel) */}
      {mobileMenuOpen && (
        <div 
          className="md:hidden border-t border-slate-200 bg-white/98 shadow-xl px-4 pt-3 pb-6 animate-in slide-in-from-top duration-200"
          id="mobile-navigation-drawer"
        >
          {/* Mobile Search input */}
          <div className="mb-4">
            <div className="relative w-full">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Tìm bài hát, nghệ sĩ (không dấu, NFC)..."
                className="w-full pl-9 pr-8 py-2 text-sm bg-slate-100 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:bg-white focus:ring-2 focus:ring-orange-300 outline-none"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-2.5 text-slate-400"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Nav Items List */}
          <div className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                    isActive 
                      ? 'bg-orange-50 text-orange-600 font-bold border-l-4 border-orange-500' 
                      : 'text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-orange-600' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded font-semibold bg-slate-100 text-slate-600">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Quick Action Button on Mobile */}
          <div className="mt-4 pt-3 border-t border-slate-100 space-y-2">
            <button
              onClick={() => {
                onOpenAutoSheetModal();
                setMobileMenuOpen(false);
              }}
              className="w-full py-2.5 px-4 rounded-xl text-center text-sm font-bold text-white bg-gradient-to-r from-orange-500 to-amber-500 shadow-sm flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Khởi Chạy Auto Sheet AI (P2)</span>
            </button>

            {/* Mobile Role Switcher */}
            <div className="pt-2 flex items-center justify-between text-xs text-slate-500">
              <span className="font-medium">Chế độ người dùng:</span>
              <div className="flex gap-1">
                {(['guest', 'member', 'admin'] as UserRole[]).map((r) => (
                  <button
                    key={r}
                    onClick={() => setUserRole(r)}
                    className={`px-2 py-1 rounded text-xs font-semibold capitalize ${
                      userRole === r ? 'bg-orange-600 text-white' : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

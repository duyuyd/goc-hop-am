import React, { useState } from 'react';
import { 
  Sparkles, 
  Search, 
  Database, 
  FileMusic, 
  ShieldCheck, 
  Activity, 
  CheckCircle2, 
  AlertCircle, 
  Play, 
  RotateCcw, 
  ListOrdered, 
  ArrowRight,
  Cpu,
  Layers,
  Music,
  Zap
} from 'lucide-react';
import { AutoSheetJob, Song } from '../types';

interface AutoSheetEngineProps {
  onSongCreated?: (newSong: Song) => void;
  onSelectSong?: (song: Song) => void;
}

export const AutoSheetEngine: React.FC<AutoSheetEngineProps> = ({ onSongCreated, onSelectSong }) => {
  const [songTitle, setSongTitle] = useState('Hạ Trắng');
  const [artist, setArtist] = useState('Trịnh Công Sơn');
  const [sourceType, setSourceType] = useState<'youtube' | 'audio' | 'midi'>('youtube');
  const [sourceInput, setSourceInput] = useState('https://www.youtube.com/watch?v=ha-trang-sample');
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const [confidence, setConfidence] = useState(0);
  const [generatedSong, setGeneratedSong] = useState<Song | null>(null);

  const pipelineSteps = [
    {
      step: 1,
      title: 'Tra cứu nội bộ & đa nguồn',
      desc: 'Quét kho bản phổ nội bộ Góc Hợp Âm và đối chiếu các nguồn mở.',
      icon: Database
    },
    {
      step: 2,
      title: 'Tìm nguồn MusicXML / MIDI / PDF',
      desc: 'Tìm kiếm dữ liệu nốt giai điệu có sẵn hoặc chuẩn bị phân tách audio.',
      icon: FileMusic
    },
    {
      step: 3,
      title: 'Gán xuất xứ & biến quyền phù hợp',
      desc: 'Thiết lập sổ quản lý nguồn gốc, phiên bản và mã hóa quyền sử dụng.',
      icon: ShieldCheck
    },
    {
      step: 4,
      title: 'Phân tích Audio Spectral & Nhận dạng',
      desc: 'Nhận dạng cao độ (pitch tracking), phát hiện vạch nhịp và hòa âm.',
      icon: Activity
    },
    {
      step: 5,
      title: 'Dựng MusicXML & Căn lời',
      desc: 'Tự động tính trường độ nốt, nhịp nghỉ, hợp âm và căn chỉnh lời ca.',
      icon: Cpu
    },
    {
      step: 6,
      title: 'Phát lại kiểm thử & Tính độ tin cậy',
      desc: 'Chạy kiểm tra tự động, đo độ tin cậy % (Đạt >= 92% mới lưu kho).',
      icon: CheckCircle2
    },
    {
      step: 7,
      title: 'Hàng đợi & Chống trùng lặp',
      desc: 'Kiểm tra checksum dữ liệu, cập nhật hàng đợi và kho lỗi riêng biệt.',
      icon: ListOrdered
    },
    {
      step: 8,
      title: 'Lưu kho dài hạn (Gán nhãn AI minh bạch)',
      desc: 'Lưu bản phổ AI vào kho Góc Hợp Âm, sẵn sàng cho việc luyện tập.',
      icon: Sparkles
    }
  ];

  const handleStartPipeline = () => {
    if (!songTitle.trim()) return;

    setIsProcessing(true);
    setActiveStep(1);
    setConfidence(0);
    setGeneratedSong(null);

    // DEMO ONLY: do not represent this timer or fixed score as a verified transcription result.
    let current = 1;
    const interval = setInterval(() => {
      current += 1;
      setActiveStep(current);

      if (current === 6) {
        setConfidence(95); // High confidence test result
      }

      if (current >= 8) {
        clearInterval(interval);
        setIsProcessing(false);

        // Build new Song object
        const newSong: Song = {
          id: `ai-song-${Date.now()}`,
          title: songTitle,
          composer: artist,
          artist: artist,
          originalKey: 'Am',
          tempo: 75,
          timeSignature: '4/4',
          genre: 'Trữ Tình / Quê Hương',
          rhythm: 'Slow Rock / Ballad',
          youtubeId: '3UfxU3y0s5o',
          sheetStatus: 'ai_generated_sheet',
          confidenceScore: 95,
          provenance: {
            origin: 'AI Auto-Sheet Engine (Pipeline v2.5 đa luồng)',
            license: 'Bản phân tích hợp âm & ký âm tự động',
            version: 'v1.0-ai-generated',
            verifiedBy: 'AI Quality Assurance System (95%)',
            lastUpdated: new Date().toISOString().split('T')[0]
          },
          lyricsWithChords: `[Am] Gọi nắng trên vai em [Dm] gầy
Đường xa [G] áo bay gió nhẹ bay [C] [E7]
[Am] Hạt nắng rơi trên tay [Dm] mềm
Tình yêu [E7] đã trao tháng ngày [Am] êm.

ĐK:
[Am] Áo xưa giờ đã [Dm] phai mầu
[G] Giọt lệ sầu rớt trên [C] bờ mi [E7]
[Am] Bước chân người về nơi [Dm] nao
[E7] Còn lại đây tiếng thở [Am] dài.`,
          sheetMeasures: [
            {
              measureNumber: 1,
              timeSignature: '4/4',
              chords: ['Am'],
              notes: [
                { pitch: 'A4', duration: 'quarter', lyric: 'Gọi' },
                { pitch: 'C5', duration: 'quarter', lyric: 'nắng' },
                { pitch: 'E5', duration: 'half', lyric: 'trên vai' }
              ]
            },
            {
              measureNumber: 2,
              chords: ['Dm'],
              notes: [
                { pitch: 'D5', duration: 'quarter', lyric: 'em' },
                { pitch: 'F5', duration: 'quarter', lyric: 'gầy' }
              ]
            }
          ],
          tags: ['AI Auto Sheet', 'Vừa tạo', 'Ngoại tuyến']
        };

        setGeneratedSong(newSong);
        if (onSongCreated) {
          onSongCreated(newSong);
        }
      }
    }, 900);
  };

  return (
    <div className="space-y-8">
      
      {/* Header Info */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-100 text-purple-700 text-xs font-bold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Hệ Thống Tự Tạo Sheet Nhạc & Hợp Âm Tự Động (P2)</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
          Auto Sheet Engine Đa Nguồn
        </h2>
        <p className="text-sm text-slate-600 max-w-3xl leading-relaxed">
          Bản AI Studio này hiện dùng quy trình minh họa, chưa thực hiện phân tích âm thanh/YouTube hoặc tạo PDF bản phổ chuẩn. Hãy dùng mục Thư Viện Sheet PDF để tìm bản phổ thật có nguồn.
        </p>
      </div>

      {/* Generator Form */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-6">
        <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
          <Zap className="w-4 h-4 text-orange-500" />
          <span>Nhập Thông Tin Bài Hát Cần Tạo Sheet</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Tên bài hát:
            </label>
            <input
              type="text"
              value={songTitle}
              onChange={(e) => setSongTitle(e.target.value)}
              placeholder="e.g. Hạ Trắng, Sầu Tím Thiệp Hồng, Nắng Ấm Xa Dần..."
              className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-orange-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Tác giả / Nghệ sĩ:
            </label>
            <input
              type="text"
              value={artist}
              onChange={(e) => setArtist(e.target.value)}
              placeholder="e.g. Trịnh Công Sơn, Hoàng Dũng, Mr. Siro..."
              className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-orange-500 outline-none"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-xs font-bold text-slate-700">
            Nguồn tham chiếu đầu vào:
          </label>
          <div className="flex flex-wrap gap-3">
            {[
              { id: 'youtube', label: 'Liên kết YouTube' },
              { id: 'audio', label: 'File Audio (MP3/WAV)' },
              { id: 'midi', label: 'File MIDI / MusicXML' },
            ].map((st) => (
              <button
                key={st.id}
                onClick={() => setSourceType(st.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                  sourceType === st.id
                    ? 'bg-orange-50 border-orange-500 text-orange-600'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>

          <input
            type="text"
            value={sourceInput}
            onChange={(e) => setSourceInput(e.target.value)}
            placeholder="Dán đường dẫn YouTube hoặc link file âm thanh..."
            className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-orange-500 outline-none text-slate-800"
          />
        </div>

        <div className="pt-2 flex items-center justify-between">
          <div className="text-xs text-slate-400">
            * Nguyên tắc: Không bịa nốt nếu thiếu dữ liệu âm nhạc; nhãn AI rõ ràng minh bạch.
          </div>
          <button
            onClick={handleStartPipeline}
            disabled={isProcessing}
            className={`px-6 py-2.5 rounded-xl text-sm font-bold text-white transition-all shadow-md flex items-center gap-2 cursor-pointer ${
              isProcessing
                ? 'bg-slate-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 active:scale-95'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>{isProcessing ? 'Đang Xử Lý Pipeline...' : 'Xem minh họa Auto Sheet (chưa phân tích thật)'}</span>
          </button>
        </div>
      </div>

      {/* 8-Step Pipeline Progress Visualizer */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-slate-900">
            Tiến Trình Pipeline 8 Bước Chuẩn Hóa
          </h3>
          {confidence > 0 && (
            <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-purple-100 text-purple-700 border border-purple-200 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-purple-600" />
              Giá trị mô phỏng: {confidence}% (không phải độ chính xác thực)
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {pipelineSteps.map((step) => {
            const Icon = step.icon;
            const isCompleted = activeStep > step.step;
            const isCurrent = activeStep === step.step;

            return (
              <div
                key={step.step}
                className={`p-4 rounded-2xl border transition-all ${
                  isCurrent
                    ? 'border-orange-500 bg-orange-50/50 ring-2 ring-orange-200'
                    : isCompleted
                    ? 'border-emerald-200 bg-emerald-50/30 text-slate-800'
                    : 'border-slate-200 bg-slate-50/50 text-slate-400 opacity-70'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${
                    isCompleted
                      ? 'bg-emerald-600 text-white'
                      : isCurrent
                      ? 'bg-orange-600 text-white animate-pulse'
                      : 'bg-slate-200 text-slate-600'
                  }`}>
                    {isCompleted ? '✓' : step.step}
                  </span>
                  <Icon className={`w-4 h-4 ${isCurrent ? 'text-orange-600' : isCompleted ? 'text-emerald-600' : 'text-slate-400'}`} />
                </div>
                <h4 className="text-xs font-bold text-slate-900 mb-1">
                  {step.title}
                </h4>
                <p className="text-[11px] text-slate-500 leading-snug">
                  {step.desc}
                </p>
              </div>
            );
          })}
        </div>

        {/* Completion Result Box */}
        {generatedSong && (
          <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 flex flex-col sm:flex-row items-center justify-between gap-4 animate-in fade-in">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-extrabold text-emerald-950">
                  Hoàn tất mô phỏng tạo bản ký âm cho: {generatedSong.title}
                </h4>
                <p className="text-xs text-emerald-800">
                  Độ tin cậy: {generatedSong.confidenceScore}% • Tone: {generatedSong.originalKey} • Điệu: {generatedSong.rhythm} • Đã thêm tạm vào danh sách của phiên duyệt, chưa lưu lên Sites.
                </p>
              </div>
            </div>

            <button
              onClick={() => onSelectSong && onSelectSong(generatedSong)}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-xs transition-colors whitespace-nowrap cursor-pointer"
            >
              Mở Bản Sheet Vừa Tạo →
            </button>
          </div>
        )}
      </div>

    </div>
  );
};

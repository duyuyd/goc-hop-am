<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/0afc881b-a0b0-4be3-9132-ab4f0bfbb4d7

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Tích hợp thư viện Sheet PDF đa nguồn — 06/11/2026

Đã thêm phần thư viện PDF vào **bản React trong ZIP này** dưới mục **Sheet PDF**. Người dùng có thể mở từ menu hoặc nút “Tìm Sheet PDF” ở mỗi bài hát. Xem `INTEGRATION_AUDIT.md` để biết giới hạn và sự khác biệt với Sites v26.

- Mã thư viện: `src/data/sheetLibrary.ts`, `src/components/SheetLibrary.tsx`.
- Test logic không cần tải thêm dependency: `npm run test:sheet` (Node.js 22+).
- Chạy frontend sau khi cài dependencies: `npm install`, `npm run dev` hoặc `npm run build`.
- Lưu ý: `backups/` là bản lưu mã nguồn cũ, không phải nội dung cần phục vụ ở đường dẫn public.
- **Chưa triển khai lên** `https://goc-hop-am.onwardcrust.chatgpt.site/` và không thay thế source Sites.
